<?php //00c6f
// *************************************************************************
// *                                                                       *
// * UddoktaPay Installer - Fast, secure, and ready to go                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:1.2.0                                                         *
// * Build Date:01 Nov 2025                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don’t comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvQg9rJNFPoRmc6oTrIX0pGEMHYClXY0EkyuG09ou9aui1Gd1Cd0oQtd5RKn2Vucoge6dE72
Uw3dnQkK2Q2uFhKTtF38OBFEUmzlVP7OGJ0HsRQBc+ohBFWMeyJ+8f9MBjkJyo48EKZi9JF6ycZJ
QXRxN6EoGMrZ9edRPYDKiArWVZVSxbmUs3V9WK3DolPQu+lwpoaMIQd08gy2VZZ5MOR/IJFzoKdL
uJ6V42Yhi7vCHooHClzc7llZ7eYGPF05hPtGvB/eh4z+fCacQa4tYofqNRIIV/O4j0sXw4z4H5Cd
Xq7/XXCaAfXmnYlpmArvytUqvhzR2j6Fg+xSLxoN35l/o3WHZZZYlXCMZKF481PBieXpiCxM9ZEe
PZLFtjPNcs06SpFEetqe0flo3v1pThrfSOr/fRrRdMDsaEtgM+G63nABNRJoKBRjV/pubaZizPpI
7hiSarx1Kbu0qYbNm/WA/ukmNAEi4zycIVLccqgtV7clw7zjKzn7mc4zl8HpQHDtFX/nVaspAXUF
hnajN4ukcfI2DtlJhEFJinnDuT8gU5F/8iHlZrM0chXV3dkrww2uGBges/rixAuvNMZswvp4ZQmu
Zs8pH/RbVY/u/RR1muyCPNvirA3me/PlS32KRkPbLPtv1817JUGwGYX1aOucXfjReFWsNrCkFR74
qx3pFPRW3cbDCsJFfiRR28ifufoCLHTee6XxHfbjBizg0SNfOJtIj4PoxzD/glFItMloFYrLAE2N
ohbyzWziScm+JwP1bh9lltKxsBZwMd7z0Lkd+NBuPxFD28crztD1r2dCKGpS+7WkqJUIMgAzLZGR
/y9AQaMt+YJD7lybKX7fdAW9PJep0+5T/OBoSmQY+iRoxT++bne7UmwTp25eGiVH22XcCT+pwROJ
BgZFEItKBMPC2V85tZz/lGZ+y9+6BKl2HIsZzX+n5Usk71YastXH9gZYr3kvAjs8p7hZ9oPSJk6N
1rQZFzqwxt8Rm2i86m1KT/pC5As2ERbKzJl7I7I12o9N2fTz/p0nEUme0XgL0ST9R7J6aovQ3Fjz
mConLtn0JenixPTbGvXUQeAsdLUKhWVGjMihIWP40yM6J3yiDlVcWh2kx1xrw39EYUnNe+/PYMeG
2cfbdefp37vd+6KQUz9oc3s+on+M06hc6rBbAaMGSANzaT/fXG39nIqVkKpYrgQfA/2uYdX08mJA
U1YqIcB8xgnYAXi3Q+/lKdgM8tJLhDak4mu5X6vtmGPGDcWNxXsW3hJk2VP0PjKr3iSP4PrOdbu4
7tQwGjYQi1zRVpGQWKkCSLuAY/1+BORtOVrEvQrc0FjYIPMJlfPcbFMrXJt/juWAWotB8yegG87I
jCjFAKEnzJKIXNP3iD7wT4s9NrXzmr7SkyUibVDq9ho2C9novBP9GH4Fin2bfku/+WjZBh8ZOGG4
BHbbQ3d/6WG4spF4b84ibIXUG+SrLDL4s62C0UJwl5mL37UBd5jFjy7Tsc5goYUr+JAdZ5L4rqgB
ubSJCm3BKVovZZPRZBXPYnaDJaotbo35j3A9hb0p3Fgvkytef7eF6jtBm74cQpq5hjLb5h77jhBo
I0m7y9/YdAP6pbyXx/TwEBqe2yZB7pOGV2uboA9YDJ/N8P144/2M/LaMwXqDO46QCxmTZEqdBstS
HmKMN4SwKAH8+mj+9PMqppbP8Put4NU0VqBL1BjHQztKtsb55ngvWmttO4mDEx6FlUK8HG4B+0YE
cI89GW1x0Rs7MsaQy+/MltQXf1Cxb9f+m9IXdyESspXzSmyw+Y5ttMShQQFKVak1WL6jIhXNo/o8
Hcj2SQvi5kYeeUYiUkhCVzZ+BNBrl3tMA0peBxYpZ6382ytCUYv9Hx8Z9qqzzWsc5b0gz6uvL933
1Eba2QTD4IJ6nnFjjKrLftvL0Gu3uBuqbpbz4jXBzQUUSm4uzeSd7rIJyAfQhDDeGNosNocRuWfD
bCvRXQ3dAXHZZcyZMFEM4YaUJYOzy5BKurqv3/whML8Gi24BpI9Im9DxTs0gt9Ffop5aW1olDEKQ
TAs1PtQ1Nm2yZds1Tjurx9FKavuuzP0ir1fOi324JH88Cj1qQjmvXTJ1WTkKz+f1+49n3vIBe68U
v3TtseTUg5vHBRDT4JVdT5WrAmmP/f3hbTBOQaBq2y/8pVBPpDiEBL/KYmSiOatdAd90+NK9PcLS
1vHhtgGLbqZUxQCwVRFMENAVklFm8DHuRdT4DYXU0XfPOANLdnktRkytugHqIhrB8fJGCpBznwHz
dV03pwXCByaS5joO8kWN5aGrUmlVAqyMM49fpIK3vInHZsARdcokNQllYFYXQwd9QYp6xUHfZNmW
+yfaImwIMlQOE/WN8K/w4u0oxBoBdYHFIcBoHuKLp2G9aonjo0LKcC9D2Tpr5o+fQU6BA3JPStov
vV7EdiMO2nSYV3qhCoCS/vFyfOPKeBqp8sdqtsFVqUlGNtruQFmuUv4bf0cvswNkWzox55eHReFk
BR6ETIftu+XPohE4mtJNVA2eYGr8MLMZvHmW0bBop7TiqdlSlkou1VOWuyrT0Yz6V0B3HmoK+sFK
o/xAaaJ0nHdyAlQ0plONwF+w0O53kqLIALpWHm67U07C2Wer0+0HyJx8M+nLJn7garmFFU+E76cY
p6VZH8S3UroCfsMlVTS9i9HOnXmS9BvHF/YJgM+y7mjqJu0tYbJZYnpg19Ha6INF10+JbulxwRJO
k3SFeb6xLjxk2TvYRTnv9alAS7NpT2LBpozHKKYZHpaoUPr2rRfenuX/+dqTxIFKOy1wh5ksGC9T
YF99wnDmE1M8y+anvcjBHqx5yGpCUxC6uiGbQ4F9CmsI0seI905bO8vEK66H0HqKD4V0o8/RlXzq
gz6vq5M1vjN3ghwTxGcXVFpwu+4uZoDWMnSGLrWKAQWWKWJwdQSaforEnKR3WpzZKfMo1dRX/wxv
Zs/Ur7FpIp/JZQGZH6S2HshJ9wOms7b7dnkAeFITgIprGydqQUl0Cpf/RyIWN+2wwm9liZz4FiZZ
CnK1ZPvlIWOIge4be7FzgSuDe4sgHM3vLB6exO+8YVzvGjrwq/0rr9JQtjh3OYRcwTMQFdoGzsoK
4/D0R6955fwZoqnW7dZHlaAGPDpd/3X6FG+zUd65Hen6TES7apuOrhLNQi6MaIrA7O3q0xA6AfHJ
6HTNDh2+zEeE+el3wZSWCVKkmrl9+46s5E9NGgPJ8MUGqblCWvCr2wZdI6vuLBmb+2PcTOFnwNrJ
JUp+Mmm48VgyYYi7wnvqsH/agsNiNqH05IgmfmStqKeW5Iw9nvwbd1MnosggmCiGnDKPLRxQFW57
hWGI7PIjgs7LpS5bsaOvuLDUrmCq+5DN8k8NQIElm5BwEi7HZOZ5mI1Lj44PQ3TnszV12HEsnpFI
gCRF4y82olhrLp0LPUnIonkM+ITAJkTuKP96w0aKb9/IbbC9uge+ZKOUKC5bS1pm2KX9Wf4BF/aB
JykXSLOfOIlMTKOr17eWusk+7rpJYr6q/7WlKyUNa7urcKvGLiVrvqIO9Di7dzT+NtvpQ1xdP/44
rWJP7Om6WV4sRGmMICeJ5rG6OHNmEsQyqZ4eMaWIc2ZoSlkEAMIicpRIZudUWG9oCUwC68UV9ZBV
vYiJLfJRpw1ITPvy31sxb1rL9E1G0hA+1skmTGt+SWVl9iyY5Hj6uVGMrup6Un86PDRPVZPuFyfZ
AfiKiUpXafwvrjCYk0==