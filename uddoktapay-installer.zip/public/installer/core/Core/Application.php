<?php //00c6f
// *************************************************************************
// *                                                                       *
// * UddoktaPay Installer - Fast, secure, and ready to go                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:1.2.0                                                         *
// * Build Date:01 Nov 2025                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don’t comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPxcQ0RFUDVg4orcKaCKSKtoXChD0omBOoi96Slp1ckl1GZ2nt2mNP7MOoHILOJEXInJMtT09
WePXXoXDp2A+BsG9YnqLcSQ2MR0tpaWlWbKx3IjVIU54spgjS/jDaiP/gCbHTJaw4n+qOpCfdZS3
QxA+JXK3MIxbMIBXOgYRMV1NYXAx7vteyYKAgjGWV433NklXBXEEDjZEE+80jRe/VZzA7igsywCr
KoScmj5qoqac9E31fZjk9UR35Laeyd+V38dcwYChAR16lCugc35l7UA+HnN/TNvHrH+2oypB5hrj
LJQdvVcBCDxuJS8r+Y4i6N5ouxYiWrmKFX08rrSycGmu/wN0hTN+Dwyew1oMtDQxWRQM3tSJlREH
7SYU3WGH3xoqGM5K4b0RXvXmVeQ16pziaXmIEfxZODxqB0phkugaV5DV5NWLRUx3uPyToWAMLudL
vPri624QpdS8WR8iFrY8MjWvvCAK2J9zHzYzH8iQwI+MyABlgq7HbUP0sM4VLmu6tny37wQ5dt82
l7nAm7rfDjMiZuPQXHvRy74U9m41ixtB7iuYypI6EJzx7/kwTiOj8EAzXSLwKy0+OhnyQ1Jlnml+
LBStavnvudWtrajJth2Fmr7wJTtZfqImwVa+56pC9101/HQQ75zjL2IU7LVA2OH0I6WKTEtzXcE3
FekjpOhVI/wuFTStVMx6jaCpTkaHla1JuHldMIwf58S+goFeepQVz8urqsI8CwcwVQkNS0Io2WZy
6zKHXGSlMUT44D3h+/LhPfksxQlo0CMwXbJTrrUiU3YsVJwDe+Ujx4Jgh+T/lS+2vfUWtdXsWzkT
8GFA0mN59KuWP5q5MbgXPmfkM4mIaRF25zTjGuXn+y4Qcgw8AwaOnNWZ+pirQ3selc+mO8Y+wwKB
g83nsHYTinHkbcBudjwEFVcOIvuXC0NCPPwlTjjnAbnOr4CYGy6RFKM9HQGqRwM7Q1tI41/o5KmW
acoAHPN64s1TWqOO2RvGAp0L3biczE+/rA4/4Vkizx5mB9mmNC59LNfKbwwz7s3FT92wA7HAWJiG
RDfvpCI/mjX+w18gjMhDCDw0xn5+Z7R1T5B+THZg1IpAz3kpAjs+Sz2FN9cT/IMIH3uLpTAe5nAR
SpRGUHMhH4UQDubaIJs+HZr6RFe6YMlGJtL8OYGKQQwXa7M05V2YJlDBS3gXjSZaoOZbuoUDAzip
svnY/pOSuCRpE/H6WuTHQ3567iY+KjOG8enOTyUnhzuxcK3JxU3NP7HfWK97GxDjeIETXdvnM1tv
1UCSdA9mErh4LyWCSeSnHYWfgvn8buKH9GcoMBHaUJxSELDglz0AVdA5WngNWvc95kneEIUz5Qni
84cUZIqTFQUdGm6HOdqeyqu30qH/37p5dsFVBovVx7JSPaiG5ym6G98e0zaqG5JM87+u/LlqgLMO
PGWfCko6PiA0o54iW2RxH4I9M+2EO+n5nySjhy1/Aj9sGLOhOosvVM31es/bEaZpfeVctPq9meLV
2lZzu5sxpWn9BOltxOvqFTUVvfCXLdgwae8J685v+ZbWNmdY2BiO67/NDZbapWA9di4dVLy0UDkJ
YS8z9/2MXJf2wIL1+vZ3xZE5++13dVZnrXbjaM/6PlvJDDKYvM2smt3wqwbevNIT7N3VJ2Y+fJaE
cnPdq6oN6kToadF8qrIv0ISvjFltaaPQTKZeC3j2qW+GTUYQu8WWV4srUbPIc1tcAtreoW33P6gC
2QrXdL68qUgzhbm0jyxJqqrmDigu8VfxOjVGpFyvSsma1LKUEhne/nXQQ+wKHXrXueAcb0CNSx6K
Xq5Tjrh4r9lctL217DuxVYewX+g8CcyASMIrYgZMqVMXsdZTTyYoxgzONTacHO+BfAz5ZqkFTx38
DW1z69b2jHJ//F8EU37tQXbt3KKz9dA1pBE4aj0cPaYfkNA2qhuN9E0kH79QlR8zGz3OnfVlGT9A
OhNDop+OC/j9QqS624za3HHEPSxxZ+WEEOSLgWVK+9+bb59S3leXl1wxtH/zZplN4ZdnPgZuTyP5
EGrlfonYnl/sMfPpEK3tJulzlaKxcsMj6tGZazw+VrzQFJcd38N5EvQJLFMginQ+wjeSitS1HHlW
3msXYIVIiZPY4w8UrrQp/0mwhRVW9js5q31xSLh4TDcYeWkWxZNKl4LeiRNdJsNNRvXHIGd0SQKW
cTG9Q4UXnipgfRE8QqSep9SqNleF4YJDqixCXI+uyhyZp2sutXr7g/BGLpFoXcEq48O5UN+tiPj6
eMybBAYoQKhi03jary5LjFamhY1FaSFp4JSiWduxnHpysLLLa0TrHyTczQ5uI9frHR67ChFt38hw
6g6PlcpbEmrptnZCJpX4N/sjUy7KSZWONDgKPq4vl6y/cR+M9GHMP3AoJGUgocrrQmZsJjSQSVzE
UhAQc8ISkG74Jj4PfLeaBrSmuqI1JegVVLgW6hlZA1twcrixiVM2CdzGn3Ej9gJ0xgFVLciAi3eP
jI2Y+iKJMYFaM06h0Pw3NjsAMaliiJT36ox9wXSX90NjhGsdhj7rjmyX0M3mglYD/UnHQ17n0ELk
bKO0t8Xvxh3c/QHwXYFoYDwmZQV0I7GhFHoESoMGWpD/oNz4wRdHGFIr4WcE32DX7vdZulfPBmYg
BhOJqA7IKVXOmNoy/rV19Hu13+qHrgZiJPvKnGs25VkLknl8uLmqN2jQEiLOGbsUWrN80lYgDYZ1
eHzGuxaXUHzeiUKeGYPdLGADDRmCug3jSd84RX7x3i585LLG/jApO/3B4mSWZAfyuhVdQP8aqfda
2Am8veC4HwKDCxGwkggAeUsvUllBKR5utqyffYEAeBBQ0/gyOalGnte5jLMSo4M93YBkGi7g045a
zUf+2yRaXvK5mRX3gRc729w5pdIWhqvnXE40aEhWpO/v4mJv8xVOejItZAUwX+m5JHmszC20bBRG
fgqEAmkfOevv7N/OL2Ixj8qCarc4wTHmn3zAC06OxdXl6Oa1fDCXsC4UGW08AP1pLEHLhP1/5Wl4
f+Q+fmdV2wHG+kq2/sYv9DQl9pd22DRVSr1OA1d9EC6tJH1Lz37t+OZzq/FPbGJaDuQOJGwadhRW
1tkswsGWmDbB6EfkEyjSOAwetaAU8VVdqeCA9aaTGXKguRCx8QTfOQndQmcTLNLSMS73wpbpwQLH
NE/5/nr3/266sJI9yWv69bKm0vw9NkF9+TnwneobhBJpmuiPXLORNPj5k+xeScQseVWcaVuS+Ptp
pF52cFpFEMd//tWYswAYdlMIDUHsy996ErrxAHmF/br3uFKxvvOWaB8qca7hZKRg+V/jC5db3V2Z
1wUvasuaAUQxn+y5ndoR2bT8cxmidkMFp7Xs2NYzdc0AO0IrQo6mIub38BEKvmP6EE6WsiWKgOWv
WAdmqR5wFkFHfMs3ZHjqA3r+FP1ztIyLXhIpSNaMlRyzUJwap1JveeYGv6E8lyN4KAZ+jqFamDx+
h7XbEI0XiGXxiU8K93uPEcFsPz4cXe7+N6pmo9AL8Ia9TJ7sBXuRuPdQ0y3o4v3vqa1dy53K5jK2
97TdiMquuf8xZOgjLmLfLM0poS3tb5+j3XizlVr5pC7329354BGxRtCG0MVGORKOZOxES5TqzyYH
MqaRlCenW2/1/14Lc4Im1e2GcDarv5Os1gNmXdwwqjN/mBUUKjJx81RovA/J0kor0O5wWzYOPfHv
O8JJLPnNnYoyPYAk/BHoULebeuKi8wMqPFepM3jCpr9qmOGAZQNeRxi7sKiE7ZQCtoWdHd7vMxzH
i/1gaDyPuLGSFu2kjscMsSV8XbOARhGqTWOeFQqWRRJz3Pv6cqW319rxBXZ1O/MlgVK6ZhktddOQ
kbfQnu5Nga+5Ovn0CkWnL9mzTM55t5LRiu61kOBApgYDeoSzMUndgwjMBBNJ38YHLhpFTI7ijwuC
y8TMbZI2rRuxvjn9YNJJFRgOuAn+4bpY/SxW0sPbFcqQ7w9V2m/7OYmkdwYHLTe0MQBV896n5w5h
jpqsbUCjEuZtRc+IbNdGLoTTFrrfcKAzAhduqsxMUaC5/7FwDEDXcWWo6wUSCNKR7wwA0jsU5m6L
YPdSFRXmExbZ5W6PbX1185cX9veihK/wZBeQf8k0QgSz6MkPyTo53zzOhtdOhAk36VywuzPIQwA+
RORWoaRi/spMdNnAOeqU4tWpLqQVe9ke9Fv/P7JY9HRu/Bf7lwDT0CrqcAYh+Rq4KY0mhxlvqK+T
7IAifbNsNz1CeoJvUdQIld8cknMdyTj6HqRgU9g+mFxp0hksFGAVclRLWDc6q9AeqFLQi98PxNa1
ilUInukVTBC1v3T+C0gSJf2e2+Y2myyOEilvHPfIWQ3knhnb8xjUG0fLnMaHUe610AZu6Bw4YurH
ZA2MCmCukCMHGu+Waaa5gWA2M2UyQyOs7qTR2kkvQ1E6UD3jvAFB2E5XxBiw1c3OD0greRhWboOl
5wIGE5mB11hHCCptv8Y0E874DA4r/npXbZgA4eEi9hQm0PshY7oaI7wQ3AsOcqqhnLvh9R1BZMmh
77QwaROLgdKozxaPt1OW/vvN+lskW5pnIfmjGWjRDpxjfvC0wFZ1wTQbHsWefTAT85IlVQcgHb3b
+Sfa0WG0Rg+nJ/SYkpKH/LY0MmI5fUVBadWxMKhFgKpmVHGqdRYQrmuHP91NwXgY3iiXNfoBtHBb
1GzVQnKmQlKg8W5qRPynKco3PpFOMmfQ2pff/pUeGFTZ5D79CU5x7UeBY96H5tWaC056DPi6bJuq
Ynoo10cIYbseX+yXj5/7enm8FgV0drgS7E4LUV3daKwcwl3oNE2IonO2RJSUFxfXpXl/H5qckmFG
omfUfj6/h+9Xqr9Fc8iW1aQWSL403ktkNtDpuFNSCpXFCv7XlfFyXuq4HiSWObVdDdiCikwQvUaO
nauJWJwWu0ioCbHcDRFAaex+Uimir8OUj/hKiss4r3X+dix0qIf6Pi0qIfb71LErS0LH4wXvdrrS
LQtpzi5WuRzsmB0XMVU4+lLW+6ZzE0XS31a5LujbzCn/z3E3Ax0rUx5C4TonuZt8QaYuCO9hrDyG
/rpn5kumPetBTBFkjoXmihMPL9cx6YBGaXUXRlzphZzFAo9fIOqFbLryMqUhSUjQv/pvIrjnnNfC
kDcC2hbNzB5SFfhA1y93lQ6OMsNq0/y2y09ErZB1XY0G6XDxPFFmguAKwOF8cRgZnq0EGh2jPRiH
em5Bhtr4VBH1oQqfn/P9OVLl2DHPaJIIeBQvVhG0SDK5/XCKLAD5+sC3Xl5jecAGQKF8igQcp0OA
gX8TqjU9dj3GlFNZ/s1Y+0tMa4pfCeI5wYtyjzWVeOj9IVCp+mQeEf+HszDNJ4OOUQAELhl412sG
E05+ilToDXyFrRJOcPaeZwIs/XEn2WzxWcRkxWQtxOG1HM9qBhxoKDr1MBLU24g0qJXkSpfnLGCl
WaKOd7ux+IzMkgUOY9qFROSx5dtDEf88NXpTx4hohMr7JkUfkhDiMr1rH4CIeguiDd1O/rJJaw4c
ZFWmDGYqOD9N37XaOIIo1E+UmKCuT22IDg1/qdsW0rbREGkzJSw05VY27M2aEBXxl3/6arKm4xiq
U5FXYJZReBRYTJV3ZnLUfMzbktypdsFOzDINZK27BWdx47BwZkEaKbFCaCh2jZ4Dt2J7lh1L6PPg
ODTwXT1DwC2DJeeiUzgi/rVB4gT4Bvbqk5UvQcYpT3LdyGwKWg8w9ZaRacvGKk2Be70JOC1b6spi
YiddjfuJiWg0uQ0gG3W2cU6h4pytNroEmBPe1ogxURSGOZL2fPRwIWxbJ7pRRXUmL0cAGgB4p21R
MTSA3ydMCLojCik0UbUEsZSFFYU5cph/lo64QgJa8a7stWjOqZ5E3uMSqES1PHmus4g9o3DE0Bq3
EPTN0KdSlOGgKXYbhutzb6NY43qEWzMKI3YZbGIFVSYZQ+4a7FrfTJ4nM2PdvrhykZYjKHreZCl5
7gOUdRJ0RHT+/dfOqCv1fSSLwdPfW+14wdmvdHfyd0hANxRU3a83NV2OQi4d01K1pkqONmWH6y0L
qdIQXVEVVOlt/+q3L2TjjqNUNglzbOTZbiiQADsqGEo6wmraXtZjbds5dEuhTzIncUDTqKzcNa5n
KbXp6W+fcaG/CskkrlPAjr2yomznu3gttznUvFnt/BRhC88UMo8eM1TXVUUfLVajUmsqLPBHEogR
CDr8b3gUnBwlrjQQAm+PzjRcVIhRZm779GYC48XPyu+D0b37Z+1Kx4Y0JW3rejtq7eg4sqngkpR3
yV/U+lONPM1G3pwZ0OVpfhMvjt2s78CdCJN2uktRv89ZJ3EPInNfX0Mpa2gP5iV7IELlFnFy6SCw
skhXiH7SeWT8qR7tKa+deO1ffrfxbWOKucvBOPLJ23+MPbzdjUWPO2PcZ/RV20/O2muKJ9WMe/7I
QMeqmn88SmeqBoK2V2bFMeSTFdQfWtLmjKJfPcLFmiZuubJYdtwi9kSj40==