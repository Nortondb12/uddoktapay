<?php //00c6f
// *************************************************************************
// *                                                                       *
// * UddoktaPay Installer - Fast, secure, and ready to go                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:1.2.0                                                         *
// * Build Date:01 Nov 2025                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don’t comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPySeLCAOeApr2Ut1uUKsDNWp8kq4Rt6srgVK+2V0+MTMP7FeKqwMYNZ5l0NFF+vbRji1iqOm
7g2lfFyxQpy5+qjVOGPpMCuYQcVG0owHg39wHsEWPtOjxh5jqCi4kf8C0SXwPehqUKnYuqEpcvzX
n0wkc05WJOgV1X5Us5NwSaX1oz5cjMWAk5M/rpKxIS5Ml4oW3Ew3k/uVBpuY6t0hlEEho7j8/yXe
5YE0ohwA7NS/yQzgi/ihrkymk8T6BwsOtI2FWd5PH/0JIqZq5OJ6Rk/pxuJr+RZsqER79Mj7LZ7m
CQjFptda+781DkT/1lvUUSErGsEJM5dgGGx7V9aCLQd0Vs8MhaYhPMMzxNqJISUDwtu69cq/XgfI
nVLMHTCWIdAST2W96qxSt7TXgoLtfSqK2X4duTad1GWNODNiIewr6AgXDhA3CwgTVkWD6Ehu/aNh
9F078U4L8FPKyowpQZ45/vsj7buzEIvHn/J2Y5ztBfD/y1B9GCvOraN5r09jv4GuSu6E2bnmrtxd
StHLzDJe6Q7kq+y6rq0mTDoyWSeEFIH7fRm5fw87bQPCLKVIUkd6oCX5w30hnjTReoRRMYX4YJf9
Zqmwub7ouUhcxGk3qAjK9REts6ZyBKsLPNpyXHPMbH3M3wvueoDmVVzRYQVpH/W9rGMxxQMSEchh
8/dgDk1E/+eC18mmxBvrQCVOBDboxxaOOh6jr+gk8md/KiVbjC4cwuCvlIUfBaTjrMQuiEmQXlDe
rz6okhIG9kWaglZnq6m0SyNNWqCU0lcyR7YFKcV4DQR0GZR9BGK9pvDvooLfz6N3WhbsgoloOrFM
De7Hq1SaPvr1ey6EqFFPpLfk5ygg2UhToehnLKjI+eRTsAfRzkIWT+hrw9SXpQ8p6OshD6nYtBNy
/dGlbO+wxxK4cwCvzu/u0R9Hq8xlYMjfqTkoJYms1+VQgNR9dSqnOcJzPKO6fffzyPPjsRbL6avj
hSn8Ct6mhjTyuuarWU62es+CSzL81OvpOBVQ0v6U7W8YsWQnH4gRX9QlwkdxNks9faFZ7B3yNiPR
b+NRAsGux2nc+QDgdTVMTSGXciodPinb+oML9OEuYoyWVXMrvHUwyThiAOQ/mcJ5Kqt7+/fp/0aC
0LraCpf4MuXFWKW8frY32e7V1jhBBVtUWfsCXufyQQCf8G+p3Rg/kMVrb39c1cX/KiZ4vw3IChoe
Hx1Xss5Y1rOaX5bjba+ZUbETngkFCTpRBgTpjjt7rPo40M08hTa6KfQVXl9kJNgG4w4k3DFa5gtW
MQUzQCd849laPhbaW9fJG8tCLHde4UCBAirZMd4AISYbBad4oSph0r54e7OwBMpznJAsKNmuXCVC
bdRj1tjeh8vb3V/03IUv8XfIGDzYcSnBVeZqvhtmpQKoVVEB/dH62KA9i1RJyg3POy18JSgYBazM
FNTy3+kY2tq/mQvnu/bdRt1KcECwMg1Per6AdeCiZphMW/IuT4G/O+uE2h1sOXqZMnHAqL8gXsZm
Y3kxYa8OD3+ydSyw6cvtwYQImafZhCKYCdECnBK/o7mwWEWfHTwn0Q/FdZ88CgN4u9FwGCymBhxI
tcjlQ5c8jZlHPHExV3KKVCqRPWlo5jwaZoXLRuxQjPRm06F4sAzidp1CCfOBelRlzDQW+x4XpB0l
emldjEcFYiPzO+WaI+KBa8Ne55r0MXbWuYtpWmjThnAkfevcTYe7/xBWXQ1wJtDxi7vdgr+RcD7D
CJtwfwePKqfwhf5eT5r3VM1ILuKZUGJxVoASQnkaTuuCsxv+pgGdg7KCds7zI/+zVLBNVhGa8hQ+
9vZDpBtA96Ak3iPLqVz9tJj2dSlmKuLP3wGUduZ55VIqJa7NQF3Y4rbUYJk8vvuAQYq6HyNqtXq9
2r3JhKxDuhe87aKtfMIdm8GJoxk5khN0RAq4UQqNNLRwL7nEQsCL5q22Jrf2xyL8W15VBsVC39so
1BYRRge++VcbOIisMNxvH2yzxZbRMNYhuCElkoDvNdekLPd9blWkj4HAcn+/IFPYV1Rx0a9QZ3iv
NLKzFjusjDdsJ36+tUZXIyKrkawuqg+RsjL6OQg+6Q2UFpeCCMRwn6qD8LRbBG7C+kJyRpGpLmCZ
LB6CtYrEA5eG7MlMxJ6OcEiaLUJqCrpWJG6O+cTPvwUG5mjgzdACWSJiwepSR7b6hu9bKoRHrfeL
LQuuUKcSfhgSR31Ow3vvL6KeZRS4299xrQsGV7Dubss1LyPGlIHglzkEQ5+bswPofSSFez6HmCz8
+oQJfpMQQoXRhkuq5vJ/X1TrMNF+jp4IFKRrHI8SY9728a0zQFQ4vMsxRpGdH+gTehop+zCMeO5u
xWAxbMlGV7R8n50dcJ3bcKbcHDEQMGlyGRXGoY/fan4v/Glz8yWQL0Gr1Fz+MUpKA4aj7c78rxOq
wYrNpN+fqyNTgVDLN545erWabkWWc8f9e7Nv0kS66ue7XIxGCackevQZsIKxmW1k/bh7gg+9wfmn
SwN0GMhIaRBhsP7zfYRBvGkw0JGKb4mXeiStwDFhomTb0hp8rtp1mN9g+6/zGwQNdFK6IMz9gx89
J0GfpOEleQ1XNXYPNxKSarRwKC63mtMRO0GP5HPCReSWAU44tgJqgQQYPpXm821tCPq2PPRq72lB
16PhMqbku6B7y9OArk1O8DFTOdGht0RU0Ln1RVkv4MjiV3HngoLRTn2Vp8+Mrd4UkyiS/2zLKyE+
MWTo6aRKETfrgbJkOZ0SB55FbQ42Qd7OUrobrsV0EmkHXHw0K0BFy0Y/HMkuzuo5e3KnKFAtjDBx
JeU+dDTBMpU3nfXGtx3Ds+jRrpw5WJ3GigFAnpW1ZCUOqgVKI9tZfTNhwdDey+yFkq1hvQAjNjGb
Zroktp6ilo/qFrcF1TfdfEWqlPLpKqloXaEtgfea5wL1X6IBC7nMqTsBDrWS5NTgfQiLFl2lcLee
5YOSqfXB5OmjV5WZOnNL49YeMWBaS9f9GLPIw+dnLy78ixljxFXQB2ZRCPqDpA5PsJ9jmmRe6V6S
XJwMX60Q6HZuNsUWxuQQfcZ3L7F72LSKqo48bmuaZWwyxrsOsDbcQzFCKcHJ4rtc8UMfvEzPY6DF
8s5si/YIhpMiVRBEuceFM6QxVxvdQlbQHApDIuBIWcQxV8hisPCrmb93dl9BQCkpHkClQECnu4ia
B2Dc21/s3G4jVWaYeJ/9UKXl+2zcHOF9MHAil1oY5i2fo4i4m7MpSsGEt22PXYMSdFHOwrrbyYv3
K0N0/T4gueBdnNBmtRNMdPQw8HGimTG8dgJ2Q5CbcseWlN8UGI6VBO1UyLUmJiqHH3cSw75lpLQK
vZ+pvXkEwDBCzc3PAXIjuvCPyH8pQf/HT8xAQ+lSrnEWbd426nGPBnXP52Btr4P243ltORBAVg7Q
xHE9AfpvB36eaKfyAjwe3cBI4PInpaaK7o3485g/plqeHF+OY2AdfHKDpvLh2vCHbihIqY4RX+hb
kXqFa4DeNNDGMVufueAKPU6KyHpO/o6sfibsKQPNALur4P0UmVrK/FzppHkVA+U/tdyYpMINX+Gg
N4GdZr3g72e+VsJsQ5XCSEWpWfquOorYYnE+zo/7bXKAA27YeCaj2BnEaDpMDjVzzsoIUELXZ9GT
D+MCrV6RuxfGzimFtDmwhFrkbxAGxm0v/9Epn469g9H4MkTNkNYlqoHybLvpSzX70vieXQonGoTi
rlrCf5lvebdor2uAWq59Fqg8zoE8lTxpCNdlWYJt2d+PzVN5puUN7DSoQhOpH4YzikYz2PjZNsuQ
ExN+LCec/qP45Hcx4AorjBfN1oXOCNI8P6F3t07W02HyCIo9XfFS08yRCQ9Eevfs3d1LMPWXEEpv
CuJUyZeZJi79GqOXrs9E4xkh/f3yV9aR9bKEDFm65GPvgu0mo8+BMAwGFu/JjISH5Q+opasnjCKI
O9bntyxMJvIUdqO7sRfgZSHtnz1bZDvM9yhLZt1xo6p1iHMVzrLtyYXBa5m1Mf1wYXbMlsZx7a6V
+aGfIq3wBXxxaoS5I/Z9MGNW3BgAuWj1oxw0a/ZWv2YESeqUE7cGlSgHxNfLdKC2No7AAaWpkKIW
vZZbqjYZzfPrQftUuUyg6IuDGIzNuDvxvEtZghtl7aQSE4XCMzd5sPLi5urrrWJTE5SP8Md0t9uk
ffkunPl3r7omHvfYTUo8EzZXfvLIMg1cDoluwuHgFOV6yI1akKAPau8hDWFttokd9o4YO2xGPQd/
NiEcu0==