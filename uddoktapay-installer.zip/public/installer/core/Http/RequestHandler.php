<?php //00c6f
// *************************************************************************
// *                                                                       *
// * UddoktaPay Installer - Fast, secure, and ready to go                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:1.2.0                                                         *
// * Build Date:01 Nov 2025                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don’t comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrWG9CVJjPpenjcnv0hPkWYglkZAHs/MZulKzHyT+XNfvZPY2Tm9KCD3R/tkkF0O7pyEYNTa
wNiWYiGSezqOzyQOUdkeK9ZqWjIuBD0d/jM9QVUf3XQfs69lp+iMIL94CmarR1J3HxnM4AVJzqbA
4HoFlfsx9bN7DIoxWcQX6iZzX2JkLDhs09o/3uarZO3+4hohq4ki4bb1ULxwA9Pow4rfaUwORjgq
A1pbB0alD3Z43wn5wU1tB7s4GmDCuKeg7slRws5Y2/kVWGxoxTD2WANizZ+A+8Vrjiyguh3VnCTs
fhYv08Bi8j6hOfJiwP8sVV08jO/5wNOSaC/7V9aC5VyeFgF2/sLRvK9Nb+ciYuhv4h1cmvJ2bMvl
7KmjOcHtgqLSGAcHk6gU3NHOnninuCLoUrTqQ6r4JtyAq4CcCaDfN/pb8m6Dh96tNN+n6saRLirc
g/v4w3MtplYklOH+T0LAtsXDcPlOgFYYBdo3Z5pjm6q685dP7PW6avLWHtyOoD7zw5pSVGruZWol
MwewI4UwmUsMBcO7A6GK3xnCnlXXXG0oXcPkx5brW7oK6Mdq8TV98JuMYz0sfGckn1OWU0WYspbA
zCJEdFpDRMezSsAO3TFfKxW+gyhLG9NRWDMKkQMfBNA6NVzaUKLjE9F6pW8LabJsCrJyDK5WvIql
BJaz1CNqv26TLe1MUGd4KeqXHugYAs+PJbe/du0hLiU+fHLI+YXBCQBkabBgZh0LkB6mbyDUucoh
r438hNXfGM/Dw9Vs3oBXrtcKHXt6mvu/si/ioC8gm88kcdH6hwqYGE9uGpfqiJA8g6fe5+qdxPaq
peuZnmqk71KIiYqv44+I+eYYhO0m5D7Jkyq/002YA3beAkepn7mYEXVJqd/lm9q4ys9LzooUXJHl
+gw3LkiRI7Sl0xryte12Y08wMqrYn0/tQ6mMTTE3CNjwVL02RdqnRgKj52cmzbv8cQaojHVHxvsy
PkLBDzODSrpHzGh0VJOAQ2FOY/CqnYh7LNzEaEc9OHH2jPm0wsasVgIPJGIb1pQA1y/XjobBmmKE
AGjURYv6G5Ddw4MRbOnpKOteGX+ScRk66kiaFgQzgYvEuzNcQa55ABXk1tVnk9KYDXkt7+EU2Jth
g5TGJw8MHQsDW5Bcvq+J7F9nrN4ZyfsaVqEWksoo5e7DELexBetNqn9SScBPTDxiusgzzBf1D9gU
EYjkPXFPwcEPVwRfOl+9o5LEzeKufl5aUl6wyiPGNj2dyiYjb65gX3CuHWFAYg0Hggdwwobhe1+n
6ZhQIq2hO2PzB/xgTcr9G4N4rcMw0HKSNZFnTji0fllAt1lLue+hHJUtWKsmyTyl3bC5J7fMJGkO
y6CHiTbi4jt0XORrYsxMKTCJt2bG/x81+1ZSLh7KVh2NHgVKOVYLwcJ7mCD3o9VD5TzvXT9PsDPU
Tyy/K4FAv9TWumZ9A/HJBSyQkbQzP5rmog5zASd5aLhqtS+1EObvUrISThNCkYgkkuQBHbtt7Uzb
x57vDIyG4ti54couVOgOrE3stL3r97f0UMufyWFgs2FHwcfc7ZJxDCnwEL/MDw+5OACQ/gVXTDSZ
ZN7wwUHF7+aNTGTodqWgAULUN/35LU96jiyppFYcLKaCvKmJia/pYPe3v2W1g48PM+sFCaGZUvG4
l+VlT02SzzVgj9AEkuIuxcdOS9wBdZzyypOGhgngnodQLAK67rpbRAY25DbaOrvD4Lvw6zM9dRlz
EqpIz9idrOtiQKPmCOVD4LnxjeG0MyPK/B7A6T1sIEyYU4p+n5SE8vkDCjqZ7F8JcSZ9HKhJBM5W
M5iPHKkrNjlA1yy81jhSZxHSQvOs+gkcUa1QLKXnqkNG5Ux0sLHkeOc5FSG9ApRSjIeudemQqhIm
7IEUuoyNgj+nxRZOTgck3fUVgVbMp8IIsRc0v6AFnm1imOCWXYzPa4pvgpNGVCSQs317VcUOE61l
RlQcK5zbV6dtbLHNZEUVXCSNUCFJTLOi3PHg1JSEWbpcrGqU3+qpv+fhBXp8q8vnG8gFvAnSCFz7
wGu41MCoO4xKjVW+9pzzDPLCN66xvFr71IICRFzkA/UiaxVFV1yUxm3u4wCFJGGDlQ7P0SStkWWH
4KYKPQprvykAOE+ngg0eNG+v+RlAdQpk+0LS3KjSLpSL9SsdCGFDLXLM8F9xvYoZs7R8T3/BupIH
z3Ty1mrpTvdnyDpGlaBPFsQaQYS1cm9E8NDRUdXVCzWx/OWlb/vz3xUzJnZxLEBFgXV9iX6BB6Y1
nGbN2wHJf6w3JVJ0HO286dfJX7VV0Iw8V0PPwI/d0oDVdArTKaxxyx5koALbKVIqca2ZCFPzxiR/
HvM/xojiFvu+60D1Ly5EUDnY0AUr4voKpof8yHxj8WTxoir0i5sKEFuLrJhUaDLnB5pJE28By54w
BUfX4uRc3XsWlj3WhvMPFMdjQ/2J5pGf8PKigQUIxRs0vYZjoYPdk3gjFUqlj9eC1s5NFpG7NbRJ
gI1PKHgne1UO0Q/u8EgwAmBMj/QKCKw8NbNfqeeYzjh1hjHRvIoMbmAIzh1YxwWT9GlBD+ZObRJU
nB3AW2KJCV2bGQvknG7t6sMVs8NVc+lwIIlaGcweyesvXu5sR+jh5mz5VmZg2bTIRtoYItFg57AJ
8y1Ii4y9junddRj+Erl1fT0wxYxWAE27JXwb+kiC1zcNLI306ocK2vvdmTA0Wj+sh4GJ+qJLAFWd
5ZhcenJ+C/n2leL7VKwqZhFldmtaUSC5xKo3NkGcW7TWk6L/e86GGyo2ZWAJNxjBrexxk/50rS0U
a/jlAW117gUjZluIR/B5io+0i2z9pgRdhCh4sG4sfPkfc+lcgsZecDA1pHg7MxEmutCjfsjklCUy
vzEqw6itTqpiWnaLObj4ZUWGkK/bmO+I8OxDdMx5lbFlgkhX4VLs+2pY+efepAWt1wqYqkWN