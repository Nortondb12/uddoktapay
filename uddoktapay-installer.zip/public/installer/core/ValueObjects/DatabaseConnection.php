<?php //00c6f
// *************************************************************************
// *                                                                       *
// * UddoktaPay Installer - Fast, secure, and ready to go                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:1.2.0                                                         *
// * Build Date:01 Nov 2025                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don’t comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPsFIxBThZjMu7XHvb2sHtWsHOfRrk6LjBuRKGHpRCdnGLLjyxfuWmHhTHt4fiJdB5VqQedhU
Fhlyj0gMDobXlm80nxmd9PaegSbUmsmK/hyE+ZMX79JVXURpSyPZEE6vTdANX6nIfmD30FLiQ4x2
NrctCC2DWHJwqgCPmocJrCs2cmKpHZwCc2YJttJklOgropuepeJKwCE0zy1wx97+VwrBN5WcNwj2
PtyjT8I3jgAYXPzH0WldtOKZdlKs5F7qrQNF0wuluYJc6WJ4OUNL/hfLjFZfzzMpQ+OMdwqi9gcg
mScDQqvAt+bU/oR5/GytVQDnHV5HroqqK8l7V9aCNaYSfZJVBZcAZxfTcbEEG7/OHnGJgA/SWdr1
3uyLEhhpTUBm9amRtJ1y+qVHSBMWTFJiDb5Fw4QT5vEIvVeijGf1ieJhtCSqWeAUb3H0iKaCcryz
2vBwAkEbUH+dac0LgVaFjW6wFLweILpwqJQcwC1LzqWUlfgEqOwdStQJE8QJPXBQOUijDRcQ/XCT
RvJFKdKkCoJnoU/EKGVwd1QS01SE1Z/lYO27+tC4bNPvhw94ayoDc2ytzdUoo/u9GntrY2lxaTM6
Yva1kh2O+b0JUBMZS6qOhm30Oy7aE59DHqKY+fYDv+QFN6iBGLpZFofoeE1Dq8K/DyvNd3R2ZoWq
PZQISI1Noujd/+EXRs+6Km9mTAR2vOw8Zcd/MS/xfQCRW65qXD7RsAx2Slx562wtdy1uoamz1ClY
/MNX+Yv5EFvFZMxv6gUmOYzqizYVd+jgCbjgRCOXefJo3AMbnQeM7RXEx1vv3x0Z2gW1XCcfx6x0
gO9037UyZzOes2zHHl4oEk6Jl++UYg6m1y7ZQq/y5Bj0SKplSC5OMKsU4epPfOUcr59aihTPaYMH
4P8x7AH0GhTRn7JnQYprCruJYXet2Sr24sDk7J5nxbfGyTCxITPUKkrXigATkyXpmJRbzhHFNqm6
iAcfIyi0tjJdrZ/84h+t76IbqNp5cV5y4y5JFl56UOaDkR2kBX4cCKf00HpqVOfOYU/uiR5pcUJI
3ZJQpZgrQZitRA4Aq9orCHLo4ekHSHhOB2USRM5RBViOHZk11Ck7Fqjgl8+Kjl+/ujY+57hZBKXH
z2dgstUc/5pGX3Oqi51M5eH2YsGkfuItRmVs9PeaI1FUQq9qEr0sYkfBUFs5khcdVuX7uX6mr1BT
48NTiW9u1WK9dQFmzlOPVt3/KaVbpK1RbjEastJbC3k2WI3ZcXL5h1QaGm6oSwHf9lJetJb3LA3f
OEFXsRCSq8tOVr9N2mfxbH6cA/SzLg1bOMfbh158fgIsOuyRJY1+2j29Gauxpujgq8hQob3j4v34
oad7a96uT1U+NbzFMl+U4tfxPxAs3uNk0ts+N0YEXN0BZ+bYIxN0eq7duf1kqPRekAIDTP1KfRE5
YUVXZf7rJRwrJSg4m5Mpq6yLuNJN8UrBmTi71lwJxKMHUN2n7tCn1cs2IW5TljHBbJECMeb0RQ+M
SkKdJ1/ZxHxd3iHUKcnmWUyxy7BsVVDR1VjUCF1lcwRrtaOvrUXZC6TXVCDOzKRul4+zwuj55Yhd
lS2CmJwin3VIYjZeWPA4ImjUiYmlx4/jtvszzS6MIGiOXjxmIV1rU8aHenoC+50LM/QEdXmQS7XC
cyMYjiURG0x11wRD1HaqAMOvBlTEy99T6ELkgSzb4v3/KuEpzYM1jU4L5w6n9PElYorL944/kIsd
UYt/sBuhr+rebGODIyhfZqVZ+ZxIbBk+IAEg4J22fruCUekkiWvZOXw6pQb2D+wI8Psq8TV5l7L3
BQZ7ke2u6r5BsVg3//5UjCUFbZ9SHhXseSoI8OMo58q3FPj7LpPonODoDAt8SVIKiuVE7alUznEy
aG5xi+Nnm1UB9oidWVkaToN53YJQdCfbKab0x00RAg1zsbP6zbXVUVc8asmQWtf7Di2K/PLm/iUM
OhIXaWnrXPHeS+OcPSXC4TbXPDBgDk2YsIiZzkfoeh1xfqBknwztczUabD7Yy36AO/s09PtGdFXy
cTms2leCEhisq0ATgclYdl7S55CYY+bYh5eZBpteQWIMM+KsZAbDhxxt0dZpfgJbcjUeEUuoxvCI
KDmVqiSIGrC+88UuAaE1BASTqsnpLzRPs+EnavMZg+gdOvBAItS7hjYAv/Qve3TPZCVDUvMkvhJQ
gpyuRlllcOxQa1AXNyFzuiOmpYxnmTRRj38+Bjnr8U0QOrttRC75qA7sknPOhyTH6KaYsgqfw9cz
QhartlXpzD4eB01x5ThfK6pPlpCS7cIiE8oa2ZVgpdFKYuVAnboRlWe4NydaEGnX7DksGrk7AHYb
EPf3S6jP6htbo5Z6Q/xNy7rcHvQCQCOBiuk+mM4/3uqX5pV8PbARuUdM4X79uiA7IpGWJw9X5HsT
wEViJq+heKA3JzeJK+wCkd06bCkqHtGBX7G7wtYIJuWpxnxlK+MR442GOaa2VgYNyfNlZ++fQI7R
JwfDqzis6B7GzK3qTJ4PhSNGZKogckcc8/ms0GybJeaEJ4xFjRH+V9pS42CNySbwEbFV7uFVjj+F
3IU369ukRamJCzXdpkBqEZToKXxyZQ+S+41UZHEcm+pIzpFSHTceOJTCoVIFupPSvlrtrtHYAhDL
P2btuieDfkojxBYZjiRkWffJwgByCS20iZPN43P9fjtUrKbVPlSoGkHk6ioX30lUJYTzMZLYuZtL
inMs128GmNxTED/tBzzNU7OGwJfNCLMMi8DnpmeOdcz4utFPrfLJJmFBhVm5p7nsRKyoiEkbVgGk
WQhv846Iit1WuucR9NU2w7GZ2eVCPmKuDMLfMpj/kZuUQs0cqF91u0MbWcEpBzbNVqV39oWSdQJv
1qc1upjq50LeTn08B9G8qCnx5XNLClOvMzEqETK1/6SILZ20YZ88JZNtdC/QzocLvhFS28GNpncD
1BDCXGjpRMG/qrAnK1BSOGycdpwUiffsnsXeGuZaTQ1S4Gps9o5n4iYTu3xFNBsqNGRVJLdRwjpP
/H7TGUUMOP6bKYyBSvlh0y08an5f8LAAbx21rj8wH5ZTUR2FR+7oK2L3PrR3mWO6YbOr6OUbIIZ5
uZ99usdXTnZkCWzaG0qTwSIGIYXA7EfesU2u5iLZcsj+HkyHsWnBgA1TND4AaqLh3JWqnNBT/9oD
zBsKsqPGXSriktXoU3iEXJcTTvApFXn+dEpgUX2Nsf/I1MMSPJMZd2i3K+2WJfbD75zSdknTcEBe
RCIDKdwgUV5TCG3D5IAhdrGkGCfVVTU3Wuov8zkbGUd+3hyugCzQ2XhlFSnmyYsjLxAEIcG5Zv5u
1oXry5SPIWMZWLFEgbR2qH6i7HB01vRQdrO7vEYHgqFuOgTOMmHeSipMMr2U3lJt4UZtRBFlLvAZ
mmOZSNJVP9hgxLBjQXQ2TWfJTg0tqTmPlXiftmmcuf55Ol2vLl/N4pVqS99IYpzKN4rfSMUKCMkF
u359b9P3i3MmySh+XWm+ceeAVfoA55xMTr5H0pdPb7+k4RAIuCZ4TFoNWZieuEb/IgEoej5k7MQ4
0TtkkL/1EIIFKq5Wa8g7APNMBzVdWnNYp+NoqfG+2HBVkEERdcz0NaSAUrwrG0EcGkBSgemT5+5I
kboYwjJ71EH09k9Mv/dPIkWVe4jTL+ybZMtJPdZXbCvfToggP4mA4aF5ToLwRPoqPAaM/0CxOokF
HXRbUPpuaFRRWITQrEVrzU+XMrrhvER/DEyj4jS35/gwfCe4JiARC6LGFSCbWj+49SdxzNEMHu9w
+R6DnvBQkgLn+HwpdGU1g9zbSSNdRO10QYigDMU7G3vdwaTlrJkWcZ7maFE7+gOMljTBkM5eW6iI
h0JoAo6EIuCJnRNOpGX9v+LS1sZCDcoMVdqG3eo5NKeldjEQQbogxn2sr4ntcKOItWq93Ym8Z4ER
I7cGWnHXZg+27xgbfQPWJErqLhwVkJTrh+lwyzKwUtUrI7tB0qwy/1yrUzAyoK6FmTs1iQ8bjud1
UXeB3jpXyTLzR7DKTk6ko/DRrB0ptDVowloBDGfPzAc27GP2VlPzXzQjGTD4N1BcUifIgrHY0XxN
GLmuQgsVAFsESOAv4+sFSTjRHsr4aXE/A/5vysp0R97yDmNaswxE/qR/fWIUfXkxWI5xeU9DJNJS
K2UkHvozC8DEOwZ5UKNUCvvA1KrXEB9OJEg/XTE9FI0gPf9KQ0re2nF5erf7rNZwOol5Rq+rh/hZ
hBxhBcFsVG+bL0mnCsV+gVWa5YYAClPGs2VFKTp7fP0CIQCLBaPF13G5ypatG/l5DW1Ibo0i8lyn
oTunUAGhw8MDAvStl0CQHtTYNvhE3W8v/nPDTG7cMmZJyqW/oUqhgN+ph360POahda+Wq7LwvK7p
VmtZanX66YyJi1LuC64TyNnNSatLW++GHF2X+B4i5dtSLvdOuB7/KqHkfxFJmCtyd5xylReeDs/R
2eOhu8FwR6Ux314TT6OUp8TSs5M6GAJvYIgRoLW42aKfYEs7y5UjdK6wDK894+s2wSfMDydWACw5
y+nowSL6igQI42zBEWe0wYDAwoYJ5e32iMsmTb8MuQmKg9dk6DLMW8Ff+MCmylTYuLyV2x51ymGq
zl6Kw1XlPz3xL6kEHehqGgQLdojtFv8+n3AE3dtggsSOurN9iOrz7NlG1yE5CZj8GTWQUns6RY9q
t6JoZLf68PhGa09ccgAQzeMGWeOx1eZ7qpfPnURtNAznFoY8VABEA3sPu8KhyhznUBeEsALWM/eq
GpcAg3MDL7G=