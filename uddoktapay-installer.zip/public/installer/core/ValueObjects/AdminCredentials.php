<?php //00c6f
// *************************************************************************
// *                                                                       *
// * UddoktaPay Installer - Fast, secure, and ready to go                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:1.2.0                                                         *
// * Build Date:01 Nov 2025                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don’t comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPyuUbQaeoMsEMTK0YW5lZsthCKv+3ZLnButKRs1VNhArwnimp6e0+JXAeA41GcBOl0Lorq1j
LhpYqq/IHyKonDcjIjkwyzIxUDyoWzsy5gDDKuAGtzbC/NpmD8MhQHsFtq4RM4r6ssKj4lXhQMt2
6a7cYJue8sS5BaNyfuxGVfFWAqcHuMsYKy/GhQ2xkE/W3vxIa+8NDDKbEE4oEk5iL6353I/TSlgG
IhAiPBLTxMB4rdZuk/9lIgmhQ/wdJffpV45j7yLiertoOpN4isy6niQ19yWF2rcGoMVq6Sen0KQq
USpOI0PqbPzEfZ3CMCxAU9dSUbkjKBoogJl7/9GCMpBWCt7hT4iftvOJWlSkaRHY4dDCb/4lhkMJ
rkvr2KZjRvwSJsTLxKV6JByOZn3FCbhbV9ljUg48fsfGaYMuqOP/FK6vDDvkAQ+DkytfGhe3hmwi
Gw5gBsEfz39h8okWWht8rr8sW6hSku2Nv//oi8DgoozPQlKcieBO7045tVfdWL8heonmcgUr6m5X
38Z9chAAxnUFfttVGSqM1A2eFX2i1VqgAy2EW1BJusiW2/cQZjjL4EJqsrk7qiTLaHf/CIr5oD2N
vq3GEBvsHiF0nOvlh6Fu3OgNlfg90YfIJoqU4MwSAjZSFYrNsywYR8Cety8NAMfLsOVdEsYA7opd
8cLcQil6weeU8i59/zHG5/gS0CTamcHehQgQPhV6vFYdUju0nYm48FA0hC6UQNxS9Y337JlkTPY2
PO9QUjpx0TN0rtLZu6xfQmYIWOmeNjhuyzAPck3DMpuoZPRz9jWefN+L0ItNitEmu6kB0s8kjth2
pd86Wa9k3wtLyhLXP5/ehSDemUj5LnoxSLcZaIdebJtCI1M5y/FY8IWirOS4zbrd+DNtIo01t0QC
A5me+xsqQISNvIe1UDg2+k3JWg7m5eXZhTbxJP5fz1l0G3w3vmTlOzBDf+WY2PDbX6BPee46FI9r
DWJuCd0h6TnP4Jf28w2FB3iMv/N+WI6xCGwZHgfFguI8hf8ZdvoCzK//0NRaQkvnzf/vx+btrlbR
4SZkuZz3hSJnX1gh0WmRuc8Y/H6wlqi+wmai1PMncbAUbUIL8aLh0NKFCwwsCBe8U58TaHu7ZGE1
PxfO0RuhXZPujtdG7ZukjU3NpAZq1aRDk2iYG6GWSEgsZ/j3d7IevCnAkckXb56TytwNrB4gmwjH
rNjsIr+sqtRq1tiCbeAs4C6kY9l8knB65zc+8QVGV5H6RWZtcV9fH1jCBhy0Agws6gCIesrRvOPg
Dc5jGRLGX0fG9BB2uc7kbEB3Sx/OeuxEMr4h6WMm7ZOYqsak1h9h1RVeJyo5ETss0zLeJ/cqi6Dq
uXWvOnwl/bA2ioi5P5+XjKL1ya/ntW+BNoYNszsYZSv9gbs0CQkeakt+kAr1aoYzcc6EgDjL/AjX
ei0ZBnil16Cd/AsaMTgMbCyfYDGRCTn5AvOhdoQ4SntTAgHYocSd3UwdHWvGmMmCfCmMx8GAL9/E
7QUj0VL2yWPeKp4O3h0BTk0u7tKlC2JhJye3I/lEvGSJht9ksI/6V47RZeCcWQ1/JSocoXqqiNBl
gKU4ZFR+eWe96AEblJZJ4yMsIw4BwVElRP/OcablKX3FXoMaGjHucwx4vnwkixKr1SXbOwP/Z7pl
26/hqt3b2KTKy956wUEhsBxdI1VOOKfpMZGFIv5Ywtr4kojXgd5EIXkcoqyr/mIDYNqUJHO5CsCP
W6ADNVvdbB1e+gIypXl2VoB3wyd6VX9K8ogcYFz7hdC+bNdMsHfa/yNlbqzso2/UpGGxTGltEqs/
WcD+XU7Hg0wUbTlv8MXJ2/r5i53KZsLdSY0DPU930SpRG2OQ9p9T/d0XPPNz0ZPe0iCK/RzqqLg3
ifrPG3kgQPbDO3vqxeUFneQ+4T+uTN20Y2MSocJLHDKRIE4UXgA0yY84xV5zlUmNCrjDAYH9RmA/
N+wrAUn5T19ZlvVRd+hR9y3HcBNxjL07IQnXZXsoNaZD0wmTYIfLRPzaUcSu/MDzocpZ/6YGQEuI
c6/6cFdMJ94rsHyq+sTB1tCImydIRSERe9RwPoxQ8gfru3kIarKRx1mRyuPuM9lO0DOFrk3HJHfT
x4UgsEtmVo1A2IJuWknKLgMmrrx9THbCRvDSeeDfRpyPeP903YeNMdG1wl8l1EY6J6FaokSD8MtZ
OXgKyN4fJhxGS92f4azFubplNchJi+UIWay+053GXFqTNuycpK3j+22i39e8r2B1HmovvTiCwhS8
xOqUY8X3wNbq20hEWFJkzh69D5d1NB65HM1mffyu18hQDHNVt1EkIm5StzYD1uC8jer3PVS/dzlM
vsTaxZjQOysAOHTPB+Mj1gpu8Nl75f4wJ7zW1IA8lk3+/NNKbjaPyDOaUM01J7Z9JvHHZIIpq085
EW3YqfglkrMiqgPLA3+vYOxCIK3B4M5GGIno2T3U5FpBc4W0zUwZ3GAI6IDZ1jBS9PRfD85sReEb
MyOXKn8YEqCW8epQdjBIsap0TyCUgq+7cwjeIlhiGo8rDTTGR6erac8wSiZNTnvKtbFWRSbazll6
XTOCO8E3GaZGG9A8zuftjDKo13iTJ5ByPU4uZnXJQaDPtxIkELe2kVdEKMycGSZuSCL3Eioqo74h
81NOSyKDHwwEhr1y+JFs0ZxSxvijvZljSZLBg0xaX3MTCSdlv4MMRIA/1J3aoh+FRPm7TPp/ayCZ
fZ3+CtQ2UYWdPWtjcL7tgVegfjKIGr4D/rO0IYcxWctUet3bjwoWguwSMDcc0ctESYSmhE+Xo64/
ANFxJQwW/B0UJiriKFLO3AFSFW1EcRTKptY5Jh9TsoQbmucCPELlaXJ1TESKakLVMp1AtKjDa6zQ
54b57ofJWU4Dzd/opDV4jxhNv2f9IC83j0DAtdP0xdeNXKVod7YisfmUDL7lMD/fz1Z4yx9mGrIU
BmLFrZWOVBGenurA/m8KnpVZGQ2dTYPaCO8x6WoGwVqmDyubo5KBMt0p4WtLMcotwgJBM6WkE1Bb
k0fc3HZYPkSAcJW98gSfEuIaU6icXJ+cq6wrcuLlOW/LsoRaFr3pVUhC/Hd74erStmwDr63/4f9v
JlFqRzBNGLJCzThsQ0WDjxSM/heY9jFPiR2USGj77uSPoQxDIBUtRhJBNc7Ufa+/SjXbnleUZ46x
I6gkwpvmX/G2qqBMtqlTE8eT/5Hggf2HDEhB+IcYGXYunXgTnsAy47cnHvUYJ/S90Q9B1nuhHIzS
obLMoLKlHBjKXqd9uWe3GR4TMYRDeriX5oJJ6ZyeIWQASqw2oxXGyWwYHsLjkWZScv9dIAFXbzC2
TD0V2KRUpbV81IFlHTcNiluNj6nFpK6JlgwPk8/mpYlCe2qKMd5Ug7wdXxSjT0ct0JxX3gumPArh
8+P5TPvXxYKfGQqfDUJqx4mWvD5r+Ya05v5yAFFx0FHIapVHIG8FgxP7mtrgb1SkJcjIgeVk6IVi
UiZG5huDgCmB3G+JzNyN+/sFcV/DGEkgFRVynkbiw3JBvy/XtGGn/p9jiQnR5FMclwVxvY8DKQ7f
b1Kkj/2U8uGu4cVPmcXq5tuxrt5KkOwJ5iebTHJZ2GMyFYjaYd/HA+KMVMBI2C+2dzKrgLlDiM0s
fptArQe=