<?php //00c6f
// *************************************************************************
// *                                                                       *
// * UddoktaPay Installer - Fast, secure, and ready to go                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:1.2.0                                                         *
// * Build Date:01 Nov 2025                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don’t comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPqqr1zDyf/la5UkIy2zfVh/MDdhAq7JjITUhKin/wnESDKW2NL9WsQZCqLNK+UUE5ZMuqWEu
It+/Q1Ri2hxXfycyboerZKvWXN2lh2AR1/RmLOIUktBz/k9ERMUUj+n7c657ze8KnCF0+9cKyfVY
K294+Qhf2S6+pBBL7SxvXdV8FzKWM3QYwNDmB5D12IxDaCddyLKqEIWsXXgi0iGkOn8Bt1kwaMed
hhGXRJOnGw+e4gSFQlrp01WUpFkoFKEahwiu2U4tqHC6vttjNM+nGUww3Eaibd8LDgQgaHHcwu+v
EcQ6hWI8QrPth3ev2s0z7RDu5XrWc5ZTwZoeWSSycWmW/y6XlxgeR5Iu9c7pGVIwH4MnxKzX3Qgz
7pthuxMEx9zb96WhdmWJ1U7/OOxkrfuZxBeTIkvXRh8z7leEwhKPADJvpPnr3oFpTHyJQ+RVlXZ1
rAbzm6pLs0rsvVbZ89pcUPYGtG6YIyf66nzMrIAyPNbsU9AyaXwGXeGpvfkQmjYmaPh5I3ZBIVnm
NHu66NOxi6dJYMHBWnyYooSpyO3zmZYstzGrznlcrk/w5G2O8XDCCTNglZePj7qNiLT/TAAMVv9R
NJRv6g6Gr6KuW3dm2KTSEiLqM/9HkBmh42O28X0/I3hfG3wCf8uWuDoJaID69SR3YsJMFgwcw6/Z
z5hLam3/Hb4wbDfD2hnO3SPvMmmbdXVNa5dtM/Gcw30kMyZclbUCglzcHwRdS1B5aEFBzPnjBDmZ
kG/sRlks16DUZsk/s3zCZ5cq6I+9SiJho0EucsyvZVmjmALDVTbax39sNeUNJ3METynq+SS1Y2EX
12Kh37YMgx8OeJLVoHQ1WBaDhgLc1gE3/SNdsqcwu8yKMs5zGRJTVZBvoFkWG6Ybt23rXJerQ9LP
/R79lQDzlv3GfL4T6QXcOPXruaQOKC8nIDMBOCHHyrol/RN3ijb25di7HFjNOLz1C4+CcpA/9JHB
f7P+W9S9Q3VfrKVtzLKGhe00qGtUCD6Z6Nzj4WpNb2InQl+rpz7wxFm7gGOkh3MPDmiMFXeHtVFv
pgVZSeah46O01E6EePeLmkt0lLeVPXJ5dde3wVq/VwMUpb+2HbV13zgcssyLOp3X3BgPdd0MYvUy
kojR+ed4SwAaBHSe9BvKKGvWW8/uuvlIP5TcGY12MGqadPrzSyu1HqsksnOYtzYWmQ+vmaHTbp1M
s7qYcjueSbh0W+tpEz93LEYSVW7aRWU3Zd2W9fFYxhjShmezVLAsPLYjYLJimfrTwZQrb/f+k8f6
hCfTfSdmx/ZXb2PXEI1BAUiOYdyMHG/EtPyKB0WlzHDWM21J3RTE3x9KSTzehqirRzVLKwR37wP/
FTYiC3ryQXWl0C5DakEmbKm4RLV8/QbqkHnqf2M2RAvnjpqcI0oT3LLAlkx+WMMXdjLzgibAETpb
bBO/5n2Dmk4X0GxOox1FS6K6Ccmit0TOTYj+BG7hF+ReP+yunY6pzX9CNTmuj3SbCPV+xWctjcYS
JML08P8/mmrp/fKkgufugslfiQ9IwY1Aj7yTjvFnWcm4lz4lD3X77+xYDRS7GevY1DE6wOyjmu4I
wtxb4H6fqYFfWuMoDrD+baaWUOj0Fe98zYkxiv3kfxL5LX+fPaEg9Dsse1uKE+yhJ7TFjn67w+sR
m5cS2/Wg6QLWFT6PVnMNdHUCxiS+vmSqsQs5mLQy76po+hzKp2wSyrh/5i/LVmSmpr16EDar9rrx
xYPq80zBHnDRtMeLE5tFivK8VFVXzRux9KjKWcGqq2+c9DTwE5n2qikhoWZIxGlXl2X60McLPPHU
o21pXvFK1Z3psFhlaKgcsVkhzcuf22lIpghwpaYN9vFmXbxp87K9AAcc7FZEUSQ27F2s319WrO2K
Kw6f0Xzk+jSqR0DC77BcpXsBgF7giBaLPL3iMY/ZOrjFQ1S7bCIM+1O6UDHcH9SuB/wSZiQcVi3S
Jx1JfbvO9I46EMS/FgKZgRXkjfEiIgsZ5H95UO8umdpMjtTrG21uau0QOr31ZcWQbd/xXoBjxUUl
haYy0d7ZepAFe9BpS//3HNUxq9GugzURpSeu+WbK7BOpP6cdhY7XnHQtNnZgvjy5c0/PhRpUeQLo
8Ntt3qaaDVi65u3yBAuX5nRRVATY/lMKtRKUQsrvKD1mI49XJ63yB8XTDuiZTYBw/w8pFwdJCjjJ
qSacApqCi1IF99qxcLW8EE1oE16NwgBpu4Qfdkd/0cmIb0jFccUJLuQTM5U9e5WZewZ4Ae/ks6XQ
0QoqOUpzUm6CJf3mCj2NqhzTbGT4zZWDutM59XBwQH/iVa08QlJGJpNUvlCTGkMxVRL4AYHPHZqP
ed3PCn6ZC3zmkJJxdA74dwm8b1CDmk5I7iMRW5gzdp8Y9QpvzTcOyGPpcc0K9xdIStr5FVcQUL6d
BQYtkniiAOqWi1BK2Ke8rCBf5r89NOx3fIIlIJGsU8nDbZ6GGCgf3AKvnH3g3C1USYG0Bt7K+SIO
KQMPamOOFvcCfq57MXOKehUe7mHC+oIaMHt3E9as8quzebwDyINZaGTPXP031v5thEwP6+62Dn5x
8ZV1HitB5N7bfYZbg0Yh7/iFVLz5GFhoN/wJJqzaP1DlbCOD/rEPN2aXSwogvn22Mt6L+nMdOprt
HO8cwuatXTdYDtGC51gTDY5ivkcMOf9nTFj50l6Uxo2Frnz58GpuAC5x2VIvPMEvJr0T1pWabHdp
FWfRYjxpNtdkDLT62bg7jYlPvG/9nMg8zt1LPQNh7WBu2VUVSQQbLPwNtl105pzBXpyfHgnGXSWI
W8qV+/EAtNPLS7yiXU2mvhbNU7nUZoI6uSx59lqM8ELDse9Ez4M/C20GK/Kq6A1nSEVUz7mCDS+V
v/cJ1ao9cUUbXIR399Vi9McM+HFEEVLVeVkSq2joow5WiUfKXKrTeg7UrrVeXErzLjsDA6rJXmWx
IYJDmY6g4AJzXm1MuigcLEX7QS1MwiO8dECUjlzDegmJsuYVH2ntj3MiBRpc0U0L+jXItfpSihpn
0CLErD001OlQN2L8E8n/ZKjnCq5zjfKVp8JASJFSRMoTV6ZqWoq1GLe+W/Fe1L3kFSyDJlIZfLOG
VPA+voemhvQuC4rxpEv9z7OTQWGvizTzW6y2MIie24w4Dkh2oezw9Ytv50mELzJtJj78ptqlyZdp
0aNpaLaxQDZ7JSRFIpcJYQVwKRdO2jMBMVrEo2zEGZ2IGYm7mixvS1EB8Ss0346vM0/FmUpMzvDS
oEcCDGYYRZruRQSg6nwiJk7yvRkb3hLUZ0GO6pK9tuZAw8ERRGTfhMfRvM2pr+qhEBjXWrq7Y7cC
hCZYazS74bBW7Lc0m0Tl9C5SOARpsNyo8PUjNSATuZqlH+PnBa148sg+3PXQok9LPKzNv9lzdVhZ
KibZJ9j85QXEBXNaiYrx4kEOIyHJPPjBi+0sgiyn2mI9Hk/G4oksSxpfA3sErib/+oFk7opKGgHq
KGCNu5EMu+ih4xKsNHBz+ip4wS4ku8+2IzAUedbzAWvFZ19os23eyONe0VHrWHxX4BowvpX9xW8i
Xq6aBRqvC8araByvib3Hi816p6WF4yU2zCFO7AuZztMrqZc+34YcvVMyrBZLfHg7Dl6RvLpmhBaY
Q6SopXBxCFFLDNMt56wOozCOTQnS3uZ6Qvt9bheHrhE3YwvIIvbeY2fZUQHGnqwr1C2y8J+k8h68
+s44gm8FcJbI5Fsdwg/Ro4vvQUr6ZvwzN/4X+s0CDbuEX7Od1fkoq+M+Ko2ssvd8MkmHyAL9q4iQ
pLlhuGduuFwpLgPw79jCwMnbTEraVUIZXV6B2GaAjxFHLVfK7/9luuadV3a2lZHmSJKzNeB9LNIK
fC0ej0BeG9XT9d8Pr+SdQ3/CgwsjGFtpNiEdDI6ZxTNCrUGWNLIi7WR+CjgSRGoVSiMWv5vQmDfZ
h3sdgTCskxWnn9Nk0AcrUh8VkgFklXr7Q4UsRqAjgqyNA1FcC8cGPPhonOnrvsU1VzKX4S8NdJvu
EOofumBzTCB9OBxCSOq0//gqM88L6Rl2Rqg94OGNEnUcVSC52na8EofAtnmWRXdwXvoSeYelkJTk
UNNhpX71UAZrs8WPnIjqFzWORnr6k+V0BdCAnqRZOuDMWynL6V/kRWrwyurL35M1GTnjuJ9/uAFe
nXBfl0wM/PPQt+pNNkqbuP8/X6sqNStIX3SbIadBrbEDPK6EJ7ygZvjagXL37MWA2cLxe6HdIoT0
ieiQ+25r19uSg0jq3kap9aL7l7OT1Bd9AP3gi6Crr3/rHs1PW8q02L/SP9RvPCHYFHlu43JNnryu
xkoPFfZW+gpH62p6FPJ+3/jLjKrlcg1oWZbR54iZSiZ23g/H75SFes52mxk6ROa2ng/odC/1Ar53
XvYUUzU7bcLiLZEFDSESNGTeyQUHZtwp0WY7UtREuS/W1SeUz38dyWWORnty0usT0BzFD69+CUXO
XJ92H4fUuFXwRkwAiU9SXIO/EaquYRjPharwHt2cIvNsNcxQSWt+jjGxp4Y8xavUWpTrqzWImkOe
ZjEcBCbopHyGoGNxzTLXYAbxwMeDAhsvuU5s+dogveyPqvAObzwNYFyc3mOOhJT1ic1zZFpkpj2x
KtPg+enncgDlaBnChpK3d71qcTKm7RxDuMWlimYq4L8Ne+pnEmAs/o1nmBhmdqQduc5Kqdcaz+hH
m1KCv6kb90qKm14QgiovE5AKZ5sinvBF9vspKKBDbymkFRNGloDKvLMLQk2KJ0kv3OjKrgvcMPuO
fPT95wW8ktdTzG277WZ9YO33Auyu46Tb9kswjExZWO9Dj5FfOUr5Z1Ai2Vk8VH2usADv0Itenifx
5DipaM4mJICYqpNbobaZEmrdMPR3DsdOSglQl0DHSRI/Ljzey225CfT25NDYY83QgyTvekE+DCni
ZrZUouqRnEMKNiZbKvOahLqNbQiJRmBSpwq+xmtxv8mjErza9kdk946R4HkXXdxW8vo7H0Q4u+D8
hBG42mJodI0cO+QwZUbDkRdpjMPfQboUnKlVqVmHM3ir5+oqLc5y1LVMZfAfKZUMHfLAqJMV0toR
QePR92H/y9ipWdGqohC9PtnLTfH0XTxuuwoFtlovBS6x0SZBEzuPp81zKEU+aefZ6kLVSSbcLcbB
1ZKrH1eRWgF7qMd8rPtjBvzpRFy4qfC7vRqnSBSniFdy2zFchwq9Ea3FjxbB9yttKF4oYornEvIT
AKRyMwJbz9uPq1/QOt5fVVuNWdOKuMw7fS2mU9n1T+yFC18AGmp6ljbigakVBckNOuJwrvQaFSD3
TvZojCsy5ILg2swXMXVUO/bLhqcidUL0/i8dHdXbGZr0INhDV7zeOGOOHtrfW7K2wo0njuZYNxWI
RZxGviUVQTgTctiDyWnQBG15S0wr878koS1jg4rvXgnAi+WfuiS2nwyafP4k60NURLMDEbK7xXb4
EZ1UZO6DPHs6g9AJ8R9abbCLEskmY9jmxFTGNL3E1eVItcncwq9EmfSWFKxEql0X//QEVThqIMwB
JS2MFJZrZT3cRB99QDETVWCSbq4zjWMx0GHSKsbYOVQag1Pid7MBD7LZqK0PhX6f5hWOwVokWLt7
JyicL4HKPEaXzSFet+RKKWiWogWDPh0ikrRSoDUkbWBOUnGaHuSb0PT6pOXNcBpGDqr66z1NNwkm
jOOcSb7GpAt0jTW5KuZBiO+70Xb1N6HVczkcImihP0yagUFozwKHAVuw6NYpdSkgkIjGsAAqcMPE
16bzLASveqCLi5qYlr9kyZVdceaqGUAYY7kO6wFywTsN7+DOMb1Nvmx9QcB8uXs9v+KbmmiYVmIn
D1pIIptVL9Y/XCnoIBrTLfESgaR/qBPRfG1RAtRWdMHXqKBzfmuQAVdQ5dsPiRhNJfMAVhJn2iS/
Hj9y3fJ9wJFHgY51JBO3EckScodSzAok+WZhnvJgRDK7FpluUMxuVHxiJDyHcdY4qyNcBbEiXGxt
MPwLEUg7b9D9XBnovHdZt1Ftw0H0t8K4z0zZmjCNQgV35Go7/qO1iMiqeNne7ByMhwR5qqWUhlxH
7vjj7Lm95FNNFhzbtNyMuSCeY8Q0TRNwfDzi+R4BaQlg328HWOHUR2CnYn9rGDNoLzcLNShPf3Zf
U28xO1AXp0Vqya6vp75CJqn7ixpVX/5lesqO+NErl15WqYunfjxy20YmMuQDn/ZH3iQyXOo+V1jY
EHFB3mBohdw7KHGz0xaXkBR6cM6deoIMJUFcJAvyR3kzZeIdg04Lem4jnKs2tgmvB7XotDMy/jwI
7/gTPhzWfOmANgh94oFbKO/wuBmEQirRQjyf1JcAha4zMSjtZBxm0p/fPrBZXIWS9sw3/kM8NT5v
rNug8YEbzG/fA5554XXrieFW7Jkin3Keqo/Uu2+fbHv7Aztsu1SL+MGmUyzn+xzIOKJ6qAh2JXYq
XEAuIRJGmfdimyRl1T2vUnysiVEEr5Su+/CORXnb9QkOzlZCpcWgjsI0nvoL9Xu1JxMr5cH8u1U6
mHYP6dBT1QFH2gHieG6kDYwVx4khnUm7/rc0eE9JuMu4iGVTgQ7ytekb97BYSHJPOj7AwD3mhReR
eSH+HpHEiKFNvjLTccB+a+Nk18K2kMDtDWkLd4Rz3TjYl3CozlGgJIDZA4XPffnjudPikRVM91no
/oYd49epDfTmUZv1y5yMBxVtUu1rAc3RvsZufpfcY82jsTJ/Ti3ILcbqn3wsJx2yJl+nozjMACcG
icXu5Qxfw7nT/wM7RmXsM3wPD5BpSJfNUNW8tfc42orFg+LqigT+l7G3savZQr3ba8wcijImkiDD
LgY+pX6wxaSDik6ThXqwppW5K1xNIeMtOvuIuW8uVt1i8IWMKP2CB5iNe1JvfN2WH2AhwGUa2cOX
3iopavsOOMbG6cmAwb61paC6PZyPQgkIkZ1RKO2Awxx0teFBMxtUplU6uMqRlP62mLzDcdzkaPvG
GCBXd5w22ySXElyGrRqxsbN38tXdwwgZothr99/KmDMm+2r2VSNV5bFkcrVxdjIrhd5BcerRbiCE
FO7ZyB2YbSPKFt8fhxUK0k/7Yey9yoBQkEvuhGlyjQB6h4Cd72DL2GWz7QWKSWo7HdC/WrlOHbuR
oBQwzJsAU8DB+iyFmFCsFfSXTkG+zJEcHV9Y77YvdG+t5MHyQ6tkns1GYC9UpeP7sARi+Rxlzg58
a/mz6Z5ZQfly+lp00HywI68VFZdsJ623f+Epb2o09QQ/tjzoma2OSm8RPsHEP/+zMmgUPDfZ9B3q
x8isz9oSzuG5qqeex20spXceS9fEwYuPTnLdF/Daz2rBDl7YnS5Bg0e4stoV5+rsD1hO51Xr/clT
rQvIheaqT781NktQJX2WNeYGbku3QoN+kL7ZSE5Dq+CB6xhJLxh6RpD7s7uxJn64/YBRyL4G13cJ
bCB3wIZiwnBzvhHDCcfvBIietb6dtkndLZgVlPPemvW=