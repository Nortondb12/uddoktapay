<?php //00c6f
// *************************************************************************
// *                                                                       *
// * UddoktaPay Installer - Fast, secure, and ready to go                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:1.2.0                                                         *
// * Build Date:01 Nov 2025                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don’t comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPvUiaTu39MeHjca4/InBygH1vETNjE0LICA8ADJxpirykqqmsgUqOPOh2y03tTRtZcJ0hSkl
52AVEjA8Dep0e2aovEnJJgpExLnAsvhv2E057p7Ry1e2CQj5unRPYTRFRp/ZViwSj9W6wC673lsH
7iRqHB8MFVZ+dTUzbopF3Y+GLggfWcQhp4S+q6Q1zLeELa/Tp9o4d3HdsqE4QODNTAQ8e9fB5E8e
p67WaQm8CrTN7w84ji4Ug7HDi8afQHsy3KBmByuK1b7kSx6+Wyk8qlq/ZlVhMDFS56X2gSF6UNlW
AIPMLnOt5hSAyEEm0eVA2dkcl/Oj7C17TIK1ntoM33N/VlAZjon05XEwikaFsYjM4KCbwcbHb7CL
A67w4d7SeZJYxPNy30XtUtyK5pqdwD1EHnshCuK8NTs2cu5efAj5/psA4Nibc9WrvbH3TzlT5lDs
MpPsojBWrdz+16j8JoiKcGQj6ATD8qq2aN/WfhbUGzcqXJx9pDRPH8sBtwZBadsKxKnB44tjpTiZ
GQiog5Hf2fBFOkaNrgHOyLKlFx3V69qVCwV9/vzZRtTmyebQxyiStvfMBtT7qj8j5zxSPC6GAall
AsjsDVOwfJPI5LcgOFy1pyieRBS47jfKVafnnM3zRHYQpPrnz7DzjJxrhM053wQOtBYwWCjt+AIw
kkuCMohYhPozBOQ+SuVcUWjxtf03ekMoVuZrEv2jXqc/fMqOdSiNBNyA5diP6LgRlsRK6LME6Q3c
DlmJ/G2OzWlmWPMecccEBR1lAMY3yYw4etcn/hMbKfntEnmj6Qq2Vrzsjew7vo+y9oSEdPBHoOtq
q5TKfrrfkDQyb5A3Fswsu0aHtyLDCBGbg8OxPbUjNkjEigbO0QmnFyYNivekOPFYDWoikdWJrHEw
CLHYJ7wtLfRPJi18h4uOXJzkyh+u+PgBfyk9/LrllL5gxrEeadM8oBFQIcu9up+QTIO2UcQkquRp
qJP5ri0cKLgXqHK0LFYNIiM1uJcIbtXKLZ6THUzU0tEhSgSe/yEcSXU+6UqHTuTH8JqrpmGaenUs
IsBf7m/cgxFKQ2jHSfNxHq+Tl/KbCndF52wqqAOURd/9/KP8ed+yascbxZBOC/zjajvkzLuSkWW8
7g9A8o8g8gh3VwuA2GvGbIRkI6w6OMnzz0pZVcIaFddYN8/pIT2ixDgoRPlZhAew46OnucSgxr65
oAkaOFa3HqOAjsFXomreXd5FR/5X38tRWL1NE35xgSFDMjRze90/EbAkt4DJ7okmJucPwK0bj1k8
yc6Fb+JKHxdsubiM2Z9bMFuwI2IgRI3GyQLRJNQcg4jdttp2M84IDWVhbuaBlGdqXDk/bU372FmX
JvKnJG/CKLZ/UUdF5bC0UPsXvkuxZQENOpC6ZPiWIeO8ufPNxCji4FE7V+he2pu5Dw1aiTrRCKtD
q1gV4ZXTJ4Mk+Qz9CrvQfzVeqaw4umfVTYvzPT6UCelKvTDHhXAP4WvAvSZ6eJXgXiX/38bw0yqk
tCawxWNLQV/6rQzoSjitdnY7mVaQ1zY/DyEc0PV7Iv2+1vl5TCldOlr08RYWYA/KvtXlG+Bv2Awa
NVtrM8W1aJrdMr1A6AoF65aJCzKVi+d5L0NG/uVoma2MZ+munw55f563+2M9wMuUiPLJxUbSaQY+
cDzvQ8TYOJRxHgWF/QI/ireZRS807jHQoaR3EUH9NoZXQH+zUyLVhPvXh9izmr039Xm7Kdf6i4BF
AQdXW6nOWFYSUQXn3mf5E63KOCLtXNJjeKAR5YEFLG2UGSyE9SBJeyG+7U1IY+LjTrMMfRGKnOoH
kbWqp4VM7XGiuZWUzmpK0Pv1mGjm57zq38fHRF/r9asKOyXVK4hg+AISdYzAQnr+vL9hUGwXdvXc
mWaQ3vPjAyO9eM8nBSPBZWIOXh9JlDc6buv56FueMhSDDAmCy4JLvSFcEGLrVSJMMOsft9Q5JEkY
Mh+jBub+1fjT9Zcjya8HkkGrojDaRxUzAdAnB6N8mrt/JIliUIxUYpjO7nV34NKKwAzjKrykH9q8
gIIPtxjnAzb3Z+9rZX8sGboY+mKHCe0z9/XF2RUGll0WtM1eHnq21g/I5UaHyxyjHfqY3pCNtMia
dVtXX1Q3bfKVg9/hKciTgoR20h/YhnS0X9+PoWAh+DEAR394San4+3dDTX8kJpIq2EZihsxS83Lz
bozpjlGGivwZuqJ+US6lmr/musvfsBOpOfIiG9ojisptkln7ufhPGrsLvmnmi02WoR7DFqycpIFu
TG8D0HwxXnJZV2RlMycF2PK0J28PU8yhi8wvMwTkgt4wmW/yhzwtFmvvlBAkBhOaBwfXJnbfxe5e
Ei+Kk5DvY+Dh+sq6tFkGP9DQdGDealPn0Dp0i9IrrEDGyvujEC1zhY8QOGp/UuJWgEpqtUcS3kwF
Wezn0DV4sOBOmYj6ElwPX2M+OXvoSKt7V6/NWAbuYMBO4mK/urx6krFdj75jBM0hco5iNbfH9xBS
+x6trw88kFNrOA9+pXXnm78JIGi0h2IY2ggVbcdgSimX1+nA+jxepSqYt0QXDnG2cl7fBLWUpA0F
6tySbtKXOfTNtRw+cdErEPd39d4aYMlyfzfXmnWe9CATXZFV5Wn0+OmOECWuODc8zX2hu9xoFYDA
ktZIb2J4Y7FFeu1OKW7MvmNcGTNQjot1N2yeA+Mmfr4cq68CAm9UaaEukuLhe3TylMBMymIS8Va1
otiUFXuvMd7zajBtCORM4a4mMRMlfKhyjfWZIbrhnlEGOYnoSw9Wv6OWQzm05k4g2UJMUnGVUMhN
oSveLv5Ut3HNd0HLe15S35ENQJT6HT03n9BfOAfNfgH+qfSVyfW0f3iDYOznM9kZPNlEZugV0thK
zpTuGfhk8gQBfAcsGOfF3yQ3B9qIxuyfvEOYemQqZUCuxfV6yHnl5udUVOQyAaATD4gr9IU6LJCc
VjMq02QjAFH49oz3XHhVoe3CiyVLx2l2Dgs9a79b21PPXR9NoTD3fMmkBCMwzTpm3hSAUyR/kHg8
GORL1szlHvD6JS2r37OhfpRwJmghphjfv5WrcO3pS1AGuplFbZ5iqkK2YRSb4eExDReh/rzEjvdE
D/m+ofdV/lVtHrm3N3bkczeKuSP2lX+nT1jXZCwIuKXFwk3lcbh43ciiu6FaqmgTqLKsooBRzNEQ
GtCUR6FA2HNtlDDi+0s37J60f2Q4nzUhh0Ko9v73xRxDIgSESOpElKmdJT8ixK2M9+bwBYt8luIX
Ep31OPuXqrK+SPOAs5iTnhFaOK5NgBeE25WthSZN3xGPeAcf8rzuJkilwo96gqVMTTqrxsLP+HFi
w7Ve6O2PtreSgbqo4jNBIFNKez6xoXBMYmRaOjEwcOfsWA61Aph5BmMtpkB0cMBI7tLayePtMKRH
A7Sg4ugClE6Px3wmDBJcZ5XRW0RF0XyCWn7qKVKmXUTAYuX0d/X3Ky5dNtIzR+dzsxY4JEfnlFJM
K4BCxzx5PMQicO8VV5idE7GsZAZcRXCznvQJuKwKCwznDMEsSubVfzFeGeoyKhtSGWxBsfek/XbF
juBIwEOvfovKWraXdXWLbB41HFGpTCDTPbCcnAgS2x1KycKPFmjWClvt63lKs4liPsvYf8P6blVu
hSOYQiwxAsbdcbE/uEG3uJz8uXwz35cB89OYj7l+nGxurU/+fkyjcsoI8NE9HYZc+DrhjaXKXm5g
VHe/8l/a+akTgJRPutETMV91KRSOyf+q/zWmfsi1aT4RrYi4NCkpRvt04chMelVmsa9k6bpcWLxy
B93giTgFLsHwoNcQAE6S+nYqZDxyADzTCInA0ve5nRQCGoiqWTjZ33PeJCBo+d4J+II2yCttAaC4
Nk86LNiSoeTSoIVfpwzIZGk3HWNkqoh2wWyaxBFNah8IkSrxMIpmiVOBzdTNIhcPG91x/WYpIV0u
xreT8nYsFp8Z+lf2Rz5GZ93dcwcMgNXizAl8aB6Ko+UCLIHkjX8wysAwZjkEDcPlluBIvPG+BAOR
iHSNr5KN2RqvPX0nHB2KzP3x2P/vAiVEF+Nwdd6Xfhkz2APs82Dv1bTYLPU/nGZfh4OeXTuI0axw
szJU7FHBs3ry2mV03NNBLEnR+P8fYl47vtq9vRNDhB49/omKus7P8aMz3v+GSZqbbRBqJocpkS22
QE2G1YkIeXp40+c6b6nhlgTfGgWdX/r/4EO7pBUWNrBR3bIye5wcKqTYSMH5RwDM6QDb+871DqEv
tELSE41E3LOi1hvWkILu10dk29sqfMUMOT4xmLyO282TIt3bjF90yGwE6Vv6GORAEO2Sd96VJTiO
uehHJ7GHSf6W2JRcYSeGPA6XX3UN0YMeuhOfFSmR9q/YtO0VXlyQQtwaPaGzWAPx1rSaoyqgazFU
zSKccZjNz60Tby4ZvWv1oV9XPPmDugpH5aqb+NPsFifNczly/8Ylte4leyn9Stt0SbDRFuNpna3A
4gPYsHy7i51MUa/j0P+V5p9GTSD/Bab1On+v9pCekOyGEpr44ApyxtEl8ZUIVg09RDY38vy3dULn
/XqrJQiZrGS8DBug9F9K