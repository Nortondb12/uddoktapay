<?php //00c6f
// *************************************************************************
// *                                                                       *
// * UddoktaPay Installer - Fast, secure, and ready to go                  *
// *                                                                       *
// *                                                                       *
// * Copyright (c) UddoktaPay. All Rights Reserved,                        *
// * Version:1.2.0                                                         *
// * Build Date:01 Nov 2025                                                *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: info@uddoktapay.com                                            *
// * Website: https://uddoktapay.com                                       *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * This software is furnished under a license and may be used and copied *
// * only in  accordance with  the terms  of such  license  and  with  the *
// * inclusion of the above copyright notice. This software  or any other  *
// * copies thereof may not be provided or otherwise made available to any *
// * other person.  No title to and  ownership of the  software is  hereby *
// * transferred.                                                          *
// *                                                                       *
// * You may not reverse  engineer, decompile, defeat  license  encryption *
// * mechanisms, or  disassemble this software product or software product *
// * license. UddoktaPay  may  terminate this  license if you don’t comply *
// * with  any of  the terms  and  conditions  set  forth in our  end user *
// * license agreement (EULA). In  such  event, licensee  agrees to return *
// * licensor  or  destroy  all  copies  of software  upon  termination of *
// * the license.                                                          *
// *                                                                       *
// *************************************************************************
if(extension_loaded('ionCube Loader')){die('The file '.__FILE__." is corrupted.\n");}echo("\nScript error: the ".(($cli=(php_sapi_name()=='cli')) ?'ionCube':'<a href="https://www.ioncube.com">ionCube</a>')." Loader for PHP needs to be installed.\n\nThe ionCube Loader is the industry standard PHP extension for running protected PHP code,\nand can usually be added easily to a PHP installation.\n\nFor Loaders please visit".($cli?":\n\nhttps://get-loader.ioncube.com\n\nFor":' <a href="https://get-loader.ioncube.com">get-loader.ioncube.com</a> and for')." an instructional video please see".($cli?":\n\nhttp://ioncu.be/LV\n\n":' <a href="http://ioncu.be/LV">http://ioncu.be/LV</a> ')."\n\n");exit(199);
?>
HR+cPrq6VRUptqMv9iBeb6i9OzdORDr/ZRwfUBVKNLJ52LzEpX6klljcNhkKL5o13JTU+JIB1GOV
DDF1iGAwJn2az/w6/6bcVgxw8SPkaMrrrN/HThOAWGs2N7mzGj9BquzWRXxMQh9nufxbHge2i3Hm
xmXjlgUNckSDEOktRP/cXA9WQNeUejecILNYLo/1Tjuc6qVYLpWmEyOQ2ij9Vlimdsl2/XG4tj5u
fT1ewv7IqwnJUDnaqeprJcYIlO4Ilko7kQ3LFqdkTA8lnTvOvQQSWfDQDzzShxNCVEgpMRiXjm+O
FauQ3kcIMEJ2xTns7y9TV5h/7m4/fMTWtyZ7F9eCOX+3NSgfIEIZTYClfSkzAvRcnz6HlCIcdAzb
nD37QkgwWW9LtpqVVSsUGgQT/qIeqkfIrcasEgEd2nVQN8aGUDwk1hu9rrRpv5Y2CoJnqfGQ5pum
kuHTR2fqumLQaOKRvTuBlE/QgWpDxYQN7R+wx5LW0tchWo1pzddERXh3aUQSUaKZaNKEhV/r+ONr
0EISABefM2y/OM3q4i6np0SeDyAj5Hx2GXisYiHyrf1QwSZ1k0xejyFjkoTSFb3D4y59/gL6PqR/
+6U5E/bgpjVal7wcnB5O1cJtXQtzjLsExWpObSYDk5zHfPK9s6U/vynopGhly8UZb7gKjXuOUVQe
UH3sQ14i/yuAi8PJvzwf2nytmRsX5vn0p5JaR9CjtiAToMILTKDjejru/xyfLv1koMM0gK+hE3XN
UHY+trfRYYNca42Mle519j43oz0+G7E6j4v+e/EwP4U/VI1GMIHfCRZMCEXlodiRH+zLISr1V2NW
ef/ojDExek9XrlUfTqUa4ge3Rx0dgzUtHvalsYl82bUA4Xq2YS9pBf74wLm40jX4yS26eKIf0EDw
2riabwDCoe7Ax+LGLcsCxMwYZN4RCkxaQljrUBkZKci+mtxZGLxWdiOgwI9tYLTIvPcNVfCitbP7
l7KBTScI0M+pVSAb2FT2dHdFymZKIjwcm0zn/BsDYpNG2pl16Wev688jBnw/maI5wknxtr7jtubV
gBtUas54x+qG9Pn6cUgGx6+phw9bYi0Ry2srzl6jKxuuCM0oILgMbqfpjJId6ITVNFITy9ZeKvuD
P767oxapeDlG/mBh+C5Mayq+64ULhXkw7dXoejeSgwNeYc7R0q0aG3wSihKfwIzOPoGpaWZb9Ds6
/kUgWXAoxzrpGQyQUDD6KHP3wuDR0jBIHK4IHqVDFl2gDYiKyBKsVjAPg8hgDueHj59nuFlelYpI
yvje3Js+c2ezTNoWtkbZzPimUB+Ktm3hXzSBtwRxgWvlUzCmBE+yBV+Fwm8/JnaNRLCRoJXVvKVp
0akaa+vFLIbcBGV4EPLZulrGZHuQztXgWJMXdAd0UKep7RrH88K26P4KWA4qk+pJVs8QuMXnjL1R
qvfDEw4Efd4b3H3QsQnWamJUcACjZsz4j2YPqxx1+UqB3OWOtYwLub4M3wMEQMFwQHtO702g58P0
+mxH5+vH/WPAwbeKpCyDb4lq2lUc/+yWsyIyno/bFK0Qr2wlwSwUpc6HBcSNwiKlDmbAyS3DH+Pr
E9sJQYWmn3X89Clhe2g8vAm9aW/0GPwbLmacCN8EzxezpAbmhW3LIMc74GY1nHLcKerbx0OPOPH0
LNFkoyhYpQfsSsFsKEbCgBRaYpEL8eRIlbxeimoX8MWX2wgCp4JFIXDv/r6tulk7e5jhFMNTXCfm
A+aJGWnhIp2D+wOK4QVSmf5kRIRzrPPqVb2WZ2PP1QlPb/YqyGe7mrVCv9Iox+hvwyjMWlwK93uw
ZoxrEUF+ZwIh7k8eUqkltKgg+cQlOA246kqPkzFN/m+xs01WnjK5x8tVNH09DyROrQuvbfU5VSXo
ULCJWOH7voJOwwpAOFQL7z2N6QNpSNND/AMc4YQ/LLt+jsOA8ENA5r0hGoIGOpwKXctufn21w1ML
ncgRMwcFHdL7RrrWhrETKrIzKrc6XQlzXJ7a6vcAY9wb6nNa0HB12lWu78KMjJbhpPcNFZVuHl4l
eDMFUAtCSM6VG/AJdNB/m6zIl4sW/XUFcl/dwrXR/gFtam+cahEXmtnpM0WKqeTI6nmQuSX2bdDR
ncw6A5mleoGQ1kLbvGIVckUjCPNLFVOCbWg/p/y4qHAa0KQ4MV4+1rA7mNNqxqFBGwopYZ/9pUg8
mrjAiM91nyxcHZ1AHaQd9jXhXL3WrQrzM+1di8/M+26NGtOTGuWNLHjO2G1tumVw7vtMbvrdSaQm
ZR2QuQAtGsjXRhJjrVS7RIQMxy5i93/3OwlH3Wxeuuw9yTEmB0dUUQXjp7YGqkvMciK3z45xAgSV
7BisO8wp1z30UqszoTvTXIx5lMoE/Im/bZFzuiCXUCg7e58mUIt580JP3l/0a7BYjQ96X8U5vgsp
fMchm9/P3zaSGEiIjBz7LvVin6uC9udYmDD8jSLmuoRrma2YrQV7tZxOyymLqr6FwO6cNWYOPC45
+7VIYPFmDx7QkkR9P7b+BpB+pfP7vbg0y5QQfHmm/SD7rBqK984odmdGkvGaoGQMNoCG3P/qestI
2ojbCUL6vPxs0bEepPoP5vmALeszKMgWfKdDC53asem4VEMPBTLlQkz9vedE9dk0lyO7VjpsnPiv
iqTgRemgqBBoKTAPqoHtMoZVyeYNH5Muy7S63efbV0SLjxEIMEk5mBPieQaNEAZx2QdPvEgGjMGs
Qjxs35xGrwY1MKlSrAH7AuEQgdgS5LA/cJBx7yBxrvwm575gtTaPLll9FlsThCfUyibkH105V4rr
Qa67e3sjDnSQLdYMH5vf3ef6EEHAzewldrHZfz3k9LI/HLCZ4FUWu0FYT3VfqvQVNAL6lRiF9ur0
NCyMbbhDsy8BLieCWcVtixmPpKPqndG413N/wL8PrHc5y+rspaDjZMU2i7Xm1D5IfiWlVdu/mFvW
6qJ5wKMKJMnJwoW58DuEAlKbQUWe/eapTpTlTGW/NBUIIfdKc57ujLDtNW4D9EApgSt5pa8ivIqC
1D19pHXkvkUTZ1WbPQPnx7HEVJDpkSQjUnFzNmfOo5gdj9BRFSsZLoEYQmi3iM33mauStGGl9AGn
JpZk2x5mDwVWF+BqcLZLIRrOuGNh9OurMZCXmg4LiwU2k05SZlOzu1gR8SxHYOWBKzTOyQAmi57H
TICmrBpjO2aRfSt77Uu/GvKIPhcQWI544wJp7bkACS2wN9iQfBxCaNdeQM/surC7UnGP/uLiZ7Jc
B4Oad0oYoE/LXlrjmR6TuzRB9wqkCPYF4d1IDvVIo4bUSHw105Df9ZIEdnhVMS00jg00SZNxPM/p
BmxVwmXH3E1heOSM3q94nUcvf/UxH4tZCjRB2dAUa2oCwqHiwwwsudl5wKJgkwg/0t9jVw17Piod
+kCHSJ1TXN172KxT4rpeqvLrp8Wc38qauRWOWzhH6/+a93C7v8+ahwd7aDLvE6MqBjEhmqQS4dBB
mso+nUf/fM+mOJiu8MqSarQsKWBElL2krnhn1OrBtyfAa9pcqg/WhydhuE1jFeXwYInPVwYzLq/B
WyVZEQNJxWOYphNLBljpDoHHkGlNnaKRcuK78NAelb2Vrmbg9lbnTBxRnCdyBZLhkHSUqpjPlhLz
cMXJ6s5NDBhuDQq2jDbVwVYqOyi11yHDueYCROQCpj9rGXSref0lM8nBQ9LDVzL/4uAzGJD9N8dS
X2eUCYDg3p2Q8ccbIZ0pZ1hGpqhxCO9YexnGlDuSJG5vc8pq96T+dDxHp3ZjD5GeKY+EtMwbUykE
2vzjejpNj9cDw+Q47BuD6wXpTaZCOXap3toTxzhPLQP7REvMLEy7HWfONOfSRUcj3aCltAJDr+E+
5TA2U45tNJ+XL+hWh3V+slNBZRupUmimV5WwBR9n4+cXzTpgds+yduHthVmVx42ExptXFnI6xed0
cmd8CJsJ8Pm8SQcvWExqhMpiCDJmecYq8CqFxNdMOHuBRzYBMszSsBuMAhgY+hkhfYIu+OrT1412
0UuU2Gkcd1Jwwe39K+DokWrtz9N/Ut61mPsuElH00QIRgXwzZptehobiC+3KsIyE7NV2X18h0Jwe
WiyS/sYufxwX3zq=